# Efficient Chebyshev Center Computation for $$\alpha$$-divergence via Proximal Point Iterations 

This peer-review capsule reproduces the main results of the article titled **Efficient Chebyshev Center Computation for $$\alpha$$-divergence via Proximal Point Iterations** by Cagatay Candan submitted to IEEE Signal Processing Letters. 

To execute, press 'Reproducible Run' button on your right. This executes `run.sh`, a shell script calling MATLAB and generates the results of  Examples 1 and 2 in the paper. (Once the runs are completed you can see the results by clicking on figEx1.png or figEx2.png links on the right pane.)

You are welcomed to conduct other experiments by changing the parameters in `figEx1.m` or `figEx2.m` in the `/code` pane (the left pane). 

## Included Materials

In the `/code` pane, in addition to this readme, you will find:

* `chebcenter_proxi.m`, Implementation of suggested method
* `arimoto76`, Implementation of Arimoto's method cited as [10] (S. Arimoto, “Computation of random coding exponent functions,” IEEE
Trans. Information Theory, vol. 22, no. 6, pp. 665–671, 1976.)
* `chencenter_fminimax.m`, Implements the solver for a numerical solution via general purpose optimization tools 
* `figEx1.m`, Example 1 script 
* `figEx2.m`, Example 2 script 
* `main.m`,   script calling both `figEx1.m` and `figEx2.m` by reproducible run botton  
* `almosteq.m`, utility function to check two variables are almost equal or not

### Author
Cagatay Candan

Department of Electrical and Electronics Engineering,  
Middle East Technical University (METU),  
Ankara, Turkey.  
<http://users.metu.edu.tr/ccandan/>