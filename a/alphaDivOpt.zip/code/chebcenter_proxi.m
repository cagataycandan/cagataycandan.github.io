function [q,Dvec,qall,thisI,thispvec] = chebcenter_proxi(Pygx,alpha,maxiter,stepsizestring)

if exist('stepsizestring','var')==0, stepsizestring = 'c'; end;
[N,M] = size(Pygx); %N output var., M input var.
funcf = @(r) (1-r.^(alpha))/alpha/(1-alpha); %alpha-div

pini = 1/M*ones(M,1); %uniform distribution as initial dist.

iter = 1;thispvec = pini; prevpvec = pini; 
qall = zeros(N,maxiter); thisI = zeros(1,maxiter);   
while(iter<=maxiter)
    if any(isnan(thispvec))==1, break; end; 
    
    q = powalphamean(Pygx,thispvec,alpha);
    qall(:,iter) = q;
       
    Dvec = Dfmat(funcf,Pygx,q);
    thisI(iter) = sum(thispvec.*Dvec(:));
    %thisI(iter) = Icalc(Pygx,thispvec,alpha); %should be the same as above
    
    if stepsizestring=='n',
        %nesterov_vec = pvec + (iter-2)/(iter+1)*(pvec-prevpvec);
        nesterov_vec = exp ( (2*iter-1)/(iter+1)*log(thispvec+1e-10) - (iter-2)/(iter+1)*log(prevpvec+1e-10) );
        prevpvec = thispvec;
        dum = nesterov_vec.*exp(Dvec(:));
    elseif stepsizestring=='a', %Adaptive step-size 
        if iter>1,
            dumy = Dfmat(funcf,qall(:,iter),qall(:,iter-1));
            dumx = KLmat(thispvec,prevpvec);
            dumc = 1 - thisI(iter)*alpha*(1-alpha);
            mu = dumx/dumc/dumy;
            mu = max(1,min(50,mu)); %Limit step size to [1,50]
        else
            mu = 1;
        end;
        dum = thispvec.*exp(mu*Dvec(:));
    else %Constant step-size 
        mu = 1; 
        dum = thispvec.*exp(mu*Dvec(:));
    end;
    
    prevpvec = thispvec; 
    thispvec = dum/sum(dum);
       
    iter = iter + 1;
end;
qall(:,iter:maxiter) = NaN*ones(N,maxiter-iter+1);
thisI(:,iter:maxiter) = NaN;

%%
function dum = Icalc(Pygx,px,alpha)
dum = (Pygx.^alpha)*px;
dum = dum.^(1/alpha);
dum = sum(dum);
dum = dum^alpha; 

dum = (1 - dum)/alpha/(1-alpha); 

%%
function q = powalphamean(Pygx,px,alpha)

dum = (Pygx.^alpha)*px; 
dum = dum.^(1/alpha); 
q = dum/sum(dum);  
%%
function out = Dfmat(funcf,Pmat,q)
%function out = Dfmat(funcf,Pmat,q)
% f    : f-divergence function, ex: funcf = @(r) r.*log(r);
% Pmat : N x M matrix where each column is a prob. dist.
% q    : a prob. dist
%
% out  : 1 x M vector with entries f-div distance of each column to q 

q = q(:); 
[N,M] = size(Pmat); 
if N~=length(q), disp('Dfmat(funcf,Pmat,q) : Dimension mismatch'); return; end; 
if any(almosteq(sum([Pmat q],1),ones(1,M+1))==0), disp('Dfmat(Pmat,q): Inputs should be prob. vectors'); return; end; 

dum = log(Pmat) - log(q)*ones(1,M);
fout = funcf(exp(dum)); qmat = q*ones(1,M); 
out = sum(qmat.*fout); 
%%
function out = KLmat(Pmat,q)
%function out = KLmat(Pmat,q)
%
% Pmat : N x M matrix where each column is a prob. dist.
% q    : a prob. dist
%
% out  : 1 x M vector with entries KL distance of each column to q 

[~,M] = size(Pmat);
if any(almosteq(sum([Pmat q(:)],1),ones(1,M+1))==0), disp('KLmat(Pmat,q): Inputs should be prob. vectors'); return; end; 

dum = log(Pmat) - log(q(:))*ones(1,M);
out = sum(Pmat.*dum); 
