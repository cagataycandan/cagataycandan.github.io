function [q,Dvec,qall,thisI,thispvec] = arimoto76(Pygx,alpha,maxiter)

[N,M] = size(Pygx); 
funcf = @(r) (1-r.^(alpha))/alpha/(1-alpha); %alpha-div
rho = (1-alpha)/alpha;

pini = 1/M*ones(M,1); 

iter = 1;thispvec = pini;
qall = zeros(N,maxiter); thisI = zeros(1,maxiter);   
while (iter<=maxiter)
    thisI(iter) = Icalc(Pygx,thispvec,alpha);
    q = powalphamean(Pygx,thispvec,alpha);
    qall(:,iter) = q;
    
    %update phi
    dum = Pygx.^(1/(1+rho)).*repmat(thispvec',N,1);
    phi = dum.';
    dum = sum(phi,1); 
    phi = phi./repmat(dum,M,1);
    
    %Update pvec
    dum = sum(Pygx.*(phi.^(-rho)).',1);
    dum = dum.^(-1/rho);
    thispvec = dum(:)./sum(dum); 

    iter = iter + 1; 
end;
Dvec = Dfmat(funcf,Pygx,qall(:,end));

%%
function dum = Icalc(Pygx,px,alpha)
dum = (Pygx.^alpha)*px;
dum = dum.^(1/alpha);
dum = sum(dum);
dum = dum^alpha; 

dum = (1 - dum)/alpha/(1-alpha); 

%%
function q = powalphamean(Pygx,px,alpha)

dum = (Pygx.^alpha)*px; 
dum = dum.^(1/alpha); 
q = dum/sum(dum);

function out = Dfmat(funcf,Pmat,q)
%function out = Dfmat(funcf,Pmat,q)
% f    : f-divergence function, ex: funcf = @(r) r.*log(r);
% Pmat : N x M matrix where each column is a prob. dist.
% q    : a prob. dist
%
% out  : 1 x M vector with entries f-div distance of each column to q 

q = q(:); 
[N,M] = size(Pmat); 
if N~=length(q), disp('Dfmat(funcf,Pmat,q) : Dimension mismatch'); return; end; 
if any(almosteq(sum([Pmat q],1),ones(1,M+1))==0), disp('Dfmat(Pmat,q): Inputs should be prob. vectors'); return; end; 

dum = log(Pmat) - log(q)*ones(1,M);
fout = funcf(exp(dum)); qmat = q*ones(1,M); 
out = sum(qmat.*fout); 
