alpha = 0.7; maxiter = 100; 
delta = 0.1;  %delta shold be in (0,0.5)  
Pygx = [0.5-delta delta     0.5-delta;
        delta     0.5-delta delta;
        delta     0.5-delta delta;
        0.5-delta  delta    0.5-delta
        ];
    
Calpha = @(alpha,delta) 1/alpha/(1-alpha)*(1-2^(2*alpha-1)*(delta^alpha + (0.5-delta)^alpha));
funcf = @(r) (1-r.^(alpha))/alpha/(1-alpha); %alpha-div

[N,M] = size(Pygx); %N output var., M input var.

%%
%%%%%%
%%ChebProxi
%%%%%%%
[qestc,dvecc,qallc,thisIc,pvecc] = chebcenter_proxi(Pygx,alpha,maxiter,'c');
[qesta,dveca,qalla,thisIa,pveca] = chebcenter_proxi(Pygx,alpha,maxiter,'a');
[qestn,dvecn,qalln,thisIn,pvecn] = chebcenter_proxi(Pygx,alpha,maxiter,'n');
[qestA76,dvecA76,qallA76,thisIA76,pvecA76] = arimoto76(Pygx,alpha,maxiter);

[qopt,dvecopt,Iopt] = chebcenter_fminimax(Pygx,alpha,maxiter,qestn); %with Nesterov-acc IC
Iopt_analytic = Calpha(alpha,delta);

%Iopt_analytic - Iopt
Iopt = Iopt_analytic; %Dikkat!
%%
linestyle = {'-','--',':','-.'};
figure(1),
subplot(211)
semilogy(1:maxiter,eps+abs([Iopt - thisIA76]),linestyle{1}); hold on
semilogy(1:maxiter,eps+abs([Iopt - thisIc]),linestyle{2});
semilogy(1:maxiter,eps+abs([Iopt - thisIn]),linestyle{3});
semilogy(1:maxiter,eps+abs([Iopt - thisIa]),linestyle{4}); hold off
set(gca,'fontsize',11); grid on;
legend({'Arimoto, [10]','Proximal-c (\mu=1)','Proximal-N (Nesterov)','Proximal-a (adaptive)'},'fontsize',11);
title(['Chebyshev radius estimation accuracy (\delta = ' num2str(delta) ', \alpha = ' num2str(alpha) ')' ]);  
xlabel('k (iteration number)'); ylabel('C_\alpha - I(Px^{(k)},P_{Y|X})'); 
ylim([1e-16 1])
set(gca,'ytick',[1e-15 1e-10 1e-5 1])
%%
%figure(2), %hold on
subplot(212)
dum = qallc - qopt*ones(1,maxiter);    errorc = sqrt(sum(dum.*dum,1));
dum = qalla - qopt*ones(1,maxiter);    errora = sqrt(sum(dum.*dum,1)); 
dum = qalln - qopt*ones(1,maxiter);    errorn = sqrt(sum(dum.*dum,1));
dum = qallA76 - qopt*ones(1,maxiter);  errorA76 = sqrt(sum(dum.*dum,1)); 

semilogy(1:maxiter,errorA76,linestyle{1}); hold on
semilogy(1:maxiter,errorc,linestyle{2});
semilogy(1:maxiter,errorn,linestyle{3});
semilogy(1:maxiter,errora,linestyle{4}); hold off
set(gca,'fontsize',11); grid on;
legend({'Arimoto, [10]','Proximal-c (\mu=1)','Proximal-N (Nesterov)','Proximal-a (adaptive)'},'fontsize',11);
xlabel('k (iteration number)'); h = ylabel('$\| \mathbf{q}^* - \hat{\mathbf{q}^{(k)}} \|$','Interpreter', 'latex');

str1 = sprintf('Fminimax    : %0.5g %0.5g  %0.5g             ',  qopt(1), qopt(2), qopt(3));
str2 = sprintf('Prox-A76    : %0.5g %0.5g  %0.5g,  q-error norm: %0.5g',  qestA76(1),   qestA76(2), qestA76(3), errorA76(end) ); 
str3 = sprintf('Prox-c      : %0.5g %0.5g  %0.5g,  q-error norm: %0.5g',  qestc(1),   qestc(2), qestc(3), errorc(end) ); 
str4 = sprintf('Prox-n      : %0.5g %0.5g  %0.5g,  q-error norm: %0.5g',  qestn(1),  qestn(2), qestn(3),errorn(end) ); 
str5 = sprintf('Prox-a      : %0.5g %0.5g  %0.5g,  q-error norm: %0.5g',  qesta(1),  qesta(2), qesta(3),errora(end) ); 

sprintf('%s\n%s\n%s\n%s\n%s',str1,str2,str3,str4,str5)
[dvecopt], [dvecA76; dvecc; dvecn; dveca], [pvecA76'; pvecc'; pvecn'; pveca'] 
title(['Chebyshev center estimation accuracy (\delta = ' num2str(delta) ', \alpha = ' num2str(alpha) ')' ]);  
set(gca,'ytick',[1e-10 1e-8 1e-5 1])
%%
saveas(gcf, '../results/figEx1.png')