function [qopt,dvecopt,Iopt] = chebcenter_fminimax(Pygx,alpha,maxiter,qini)

funcf = @(r) (1-r.^(alpha))/alpha/(1-alpha); %alpha-div
distCost = @(x) Dfmat(funcf,Pygx, [x ; 1 - sum(x)]); 

if exist('qini','var')==0, 
    qini = chebcenter_proxi(Pygx,alpha,maxiter,'n'); %Use Nesterov-accelerated version as IC
end; 

options = optimoptions('fminimax'); 
options.Display = 'none'; %options.Display = 'iter';
options = optimoptions(options, 'FunctionTolerance', 1e-13, 'StepTolerance', 1e-13);

dum = fminimax(@(q) distCost(q),qini(1:end-1),[],[],[],[],[],[],[],options);

qopt = [dum; 1-sum(dum)]; 
dvecopt = Dfmat(funcf,Pygx,qopt);
Iopt = max(dvecopt); %Dikkat!
%%
function out = Dfmat(funcf,Pmat,q)
%function out = Dfmat(funcf,Pmat,q)
% f    : f-divergence function, ex: funcf = @(r) r.*log(r);
% Pmat : N x M matrix where each column is a prob. dist.
% q    : a prob. dist
%
% out  : 1 x M vector with entries f-div distance of each column to q 

q = q(:); 
[N,M] = size(Pmat); 
if N~=length(q), disp('Dfmat(funcf,Pmat,q) : Dimension mismatch'); return; end; 
if any(almosteq(sum([Pmat q],1),ones(1,M+1))==0), disp('Dfmat(Pmat,q): Inputs should be prob. vectors'); return; end; 

dum = log(Pmat) - log(q)*ones(1,M);
fout = funcf(exp(dum)); qmat = q*ones(1,M); 
out = sum(qmat.*fout); 

%%
function out = KLmat(Pmat,q)
%function out = KLmat(Pmat,q)
%
% Pmat : N x M matrix where each column is a prob. dist.
% q    : a prob. dist
%
% out  : 1 x M vector with entries KL distance of each column to q 

[~,M] = size(Pmat);
if any(almosteq(sum([Pmat q(:)],1),ones(1,M+1))==0), disp('KLmat(Pmat,q): Inputs should be prob. vectors'); return; end; 

dum = log(Pmat) - log(q(:))*ones(1,M);
out = sum(Pmat.*dum); 
