
disp '******************************************';
disp '            Run for Example 1             ';
figEx1,  
disp ' -------> Done with Example 1 <-----------';
disp '       (see figEx1.png for results)       ';
disp '******************************************';

disp '******************************************';
disp '            Run for Example 2             ';
figEx2,  
disp ' -------> Done with Example 2 <-----------';
disp '       (see figEx2.png for results)       ';
disp '******************************************';