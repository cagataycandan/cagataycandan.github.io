function out=almosteq(A,B,tol)
%Is A and B almost equal ?, tolerance=1e-3^tol

if any(size(A)~=size(B)), disp 'Dimensions do not match';return;end
if nargin==2, tol=1;end;
out=((abs(real(A)-real(B)))<1e-3^tol)&((abs(imag(A)-imag(B)))<1e-3^tol);


