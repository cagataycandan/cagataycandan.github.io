# Covariance Matrix Estimation for Noisy Texture-Correlated Compound-Gaussian Vectors

This capsule reproduces the numerical results of the study titled **Covariance Matrix Estimation for Noisy Texture-Correlated Compound-Gaussian Vectors** by Cagatay Candan submitted to IEEE Signal Processing Letters (March 2020). 

To execute the code, press blue colored 'Reproducible Run' button on your right. This executes `run.sh`, a shell script calling MATLAB to start Monte Carlo experiments similar to the ones in Figures 2, 3 and 4 of the text. 

To have simulations with other parameters, you can change the parameters given in paperfig__SCNR*.m (three files in the left panel, generating three figures by running `main.m`) and hit `Reproducible Run` button. 

## Included Materials

In the `/code` pane, in addition to this readme, you will find:

* `main.m`: Main file implementing the Monte Carlo Experiments
* `paperfig___SCNR_vs_Target_Vel.m`: script called from `main.m` to generate SCNR vs. Target velocity results
* `paperfig___SCNR_vs_L.m`: script called from `main.m` to generate SCNR vs. L results
* ` paperfig___SCNR_vs_L_KdistClutter.m`: script called from `main.m` to generate SCNR vs Target velocity for K-distributed clutter
* `cov_mat_estHMM.m`: Suggested covariance matrix estimator
* `cov_mat_est_Tyler.m`: Tyler's covariance matrix estimator
* `gen_markov_process.m`: Generates Markov Chain realization (required for HMM)
* `generate_correlated_gamma.m`: Generates correlated Gamma variates (required for K-distributed clutter simulation)
* `writetime.m`: A simple function to display the script execution time

### Author
Cagatay Candan

Department of Electrical and Electronics Engineering,  
Middle East Technical University (METU),  
Ankara, Turkey.  
<http://users.metu.edu.tr/ccandan/>