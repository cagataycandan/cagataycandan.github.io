function out = gen_markov_process(p0,P,Ns)
%function out = gen_markov_process(p0,P,Ns)
%
% Generates Markov random process samples of length Ns
% with the state transition matrix P and initial probability
% assignment of p0. 
%
% Cagatay Candan
% Nov. 2019
%

%To check
% Ptry = round(rand(3,3)*10)/10; Ptry = Ptry*diag(1./sum(Ptry));
% [Evec,eval] = eig(Ptry); 
% p0try = Evec(:,1); p0try = p0try./sum(p0try); 
% rp = gen_markov_process(p0try,Ptry,10e3);
% for k1 = 1:3,
%    ind1 = find(rp(1:end-1)==k1);
%    dum  = rp(ind1 + 1); 
%     for k2 = 1:3,
%       Ptryest(k2,k1) = sum(dum==k2)/length(dum);
%     end;
% end;
% Ptry,Ptryest


out = zeros(1,Ns);
out(1) = sample_from_p0(p0);
for thisn=2:Ns,
    this_p0 = P(:,out(thisn-1));  
    out(thisn) = sample_from_p0(this_p0);
end;


%%%
function out = sample_from_p0(p0)
vec = 1:length(p0);
u = rand(1);
ind = (u>=cumsum(p0));
out = vec(sum(ind)+1);
