function writetime
fprintf('---- %s ---- \n',datestr(now))
