function [Rest,posterior_prob] = cov_mat_estHMM(r,P,p0,gamma_vec,Rini,maxiter,sigma_v_sq);

[N,L] = size(r);
num_states = size(P,1);
gamma_vec = gamma_vec(:);

%maxiter  = 10;
if nargin==4, Rini = eye(N); end;

%Rinvs{length(gamma_vec)} =[]; Kmat{length(gamma_vec)} = [];
Rest = Rini; iter = 0;
while (iter<maxiter),
    iter = iter + 1;
    
    %     for indgamma= 1:length(gamma_vec)
    %         thisgamma = gamma_vec(indgamma);
    %         dum = inv(Rest*thisgamma + sigma_v_sq*eye(N));
    %         Wmat{indgamma} = dum*thisgamma*Rest;
    %         Kmat{indgamma} = thisgamma*Rest - thisgamma^2*Rest*dum*Rest;
    %     end;
    %
    posterior_prob = runab_covmat2(r,P,p0,gamma_vec,Rest,sigma_v_sq);
    
    Restnew = 0; sumK = 0; avg_posterior_prob = 1/L*sum(posterior_prob,2);
    for indgamma= 1:length(gamma_vec)
        thisgamma = gamma_vec(indgamma);
        dum = inv(Rest*thisgamma + sigma_v_sq*eye(N));
        thisKmat = thisgamma*Rest - thisgamma^2*Rest*dum*Rest;
        sumK = sumK + avg_posterior_prob(indgamma)/thisgamma*thisKmat;
        
        dum = thisgamma*Rest*dum*r;
        dum = bsxfun(@times,dum,sqrt(posterior_prob(indgamma,:)/thisgamma));
        Restnew = Restnew + dum*dum';
    end;
    Rest = 1/L*Restnew + sumK;
    %     Rest = 0;
    %     for snapshot=1:L,
    %         for indgamma= 1:length(gamma_vec)
    %             thisgamma = gamma_vec(indgamma);
    %             dumvec = Wmat{indgamma}'*r(:,snapshot);
    %             Rest = Rest + posterior_prob(indgamma,snapshot)/thisgamma*dumvec*dumvec';
    %         end;
    %     end;
    %     Rest = 1/L*Rest;
    %
    %     sumK = 0; avg_posterior_prob = 1/L*sum(posterior_prob,2);
    %     for indgamma= 1:length(gamma_vec),
    %         thisgamma = gamma_vec(indgamma);
    %         sumK = sumK + avg_posterior_prob(indgamma)/thisgamma*Kmat{indgamma};
    %     end;
    %     Rest = Rest + sumK;
end;

%Rest = Rest/sum(diag(Rest))*N;


%%%%%%%%%%%%%%%%%%
function posterior_prob = runab_covmat2(r,P,p0,theta_vec,Rest,sigma_v_sq)

[N,L] = size(r); 
num_states = size(P,1);
theta_vec = theta_vec(:); 

ind = 0; Rinvs{length(theta_vec)} =[]; logdetR = zeros(length(theta_vec),1);
for thistheta = theta_vec.'
    ind = ind + 1; 
    dum = Rest*thistheta + sigma_v_sq*eye(N); 
    Rinvs{ind} = inv(dum); logdetR(ind) = log(real(det(dum))); 
end;

%Restinv = inv(Rest + sigma_v_sq*eye(N)); 
%loglikelihood = @(x,par,Rest) -0.5*N*log(par) - 0.5*(x'*inv(Rest + sigma_v_sq*eye(N))*x)./par;
%likelihood = @(x,par,Rest) exp(loglikelihood(x,par)); 

%alpha recursion
alpha = zeros(num_states,L);
dum = likelihood(r(:,1),Rinvs,logdetR).*p0;
alpha(:,1) = dum/sum(dum); 
for ind = 2:L,
    dum = P*alpha(:,ind-1);
    dum = likelihood(r(:,ind),Rinvs,logdetR).*dum;
    alpha(:,ind) = dum/sum(dum);
end;

%beta recursion
beta = zeros(num_states,L);
dum = ones(num_states,1);
beta(:,end) = dum/sum(dum); 
for ind = L-1:-1:1,
    dum = likelihood(r(:,ind),Rinvs,logdetR).*beta(:,ind+1);
    dum = P'*dum;
    beta(:,ind) = dum/sum(dum);
end;

posterior_prob = alpha.*beta;
posterior_prob = bsxfun(@rdivide,posterior_prob,sum(posterior_prob,1));

%%%
function out = likelihood(x,Rinvs,logdetR)
out = zeros(length(Rinvs),1); 
for ind = 1:length(Rinvs)
    %out(ind) = 1/sqrtdetR(ind)*exp( -0.5*real(x'*Rinvs{ind}*x) );
    out(ind) = 0.5*real(x'*Rinvs{ind}*x) + 0.5*logdetR(ind); %negative log-likelihood
end; %note: complex data case has two times the calculuated likelihood 
out = out - min(out); %divide likelihood by a common factor, subtract from log-likelihood 
out = exp(-out); 

