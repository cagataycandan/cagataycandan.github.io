%L = 40;    %number of snapshots
Lvec = 10:10:50;
Npulse = 10;     % dimension of snapshot vector
PRF = 3e3;       % in Hz
MCnum = 50;      % use higher values for more accuracy
iterEM = 100;

%Target/Clutter/Noise parameters
target_vel = 10;        %in m/sec
SNR_dB = 10;
clutter_mean_vel = 3;  %in m/sec
clutter_sigmav = 1;    %in m/sec
CNR_dB = 10;
sigma_v_sq = 1;        %Noise varianceT

%Markov Chain Parameters
stay_in_prob = 0.9;
theta_vec = [0.01 0.1 1 10 100];
num_states = length(theta_vec);
p0 = 1/num_states*ones(num_states,1);           %Equally likely state
%p0 = zeros(num_states,1); p0(theta_vec==1) = 1;  %Starts from CUT power level

%Constants
fc = 10e9;c = 3e8;lambda = c/fc;
PRI = 1/PRF; CNR = 10^(CNR_dB/10); SNR = 10^(SNR_dB/10);

vmax = PRF*lambda/2;
if target_vel>vmax,
    disp(['Warning: Maximum target velocity exceeds ambiguious velocity of ' num2str(vmax) ' m/sec.']);
end;

%Clutter Cov. Mat.
fd_sea = 2*clutter_mean_vel/lambda; sigma_sea = 2*clutter_sigmav/lambda;
clutter_dop_center = exp(1i*2*pi*fd_sea*PRI*(0:Npulse-1).');
rho = exp(-pi^2*2*(sigma_sea*PRI)^2); Rc = toeplitz(rho.^((0:Npulse-1).^2));
Rc = CNR*diag(clutter_dop_center)*Rc*diag(conj(clutter_dop_center));
sqrtRc = sqrtm(Rc);

%Markov Chain Transition Probability
P = (1-stay_in_prob)/(num_states-1)*ones(num_states,num_states) + ...
    (num_states*stay_in_prob - 1)/(num_states-1)*eye(num_states,num_states);

h = waitbar(0,'Please wait...'); ind_L = 0; 
SCNRmat = zeros(length(Lvec),MCnum,4); meanSCNRmat = zeros(length(Lvec),4); 
for L = Lvec,
    ind_L = ind_L + 1; 
    %Target
    fd_target = 2*target_vel/lambda;
    s_doppler = exp(1i*2*pi*fd_target*PRI*(0:Npulse-1).')/sqrt(Npulse);
    
    %%
    SCNR_max = [];
    for indMC = 1:MCnum,
        %Generate data
        state_seq = gen_markov_process(p0,P,L);
        s = theta_vec(state_seq); %s is the unknown variance sequence
        Xmat = sqrtRc*1/sqrt(2)*(randn(Npulse,L) + 1i*randn(Npulse,L));
        r = bsxfun(@times,Xmat,sqrt(s)) + sqrt(sigma_v_sq/2)*(randn(Npulse,L) + 1i*randn(Npulse,L));
        
        %Estimators
        Rini = 1/L*(r*r'); Rini = Rini/sum(diag(Rini))*Npulse;
        %Rini = cov_mat_est_Tyler(r,Rini_Tyler,5);
        [Rest,posterior_prob] = cov_mat_estHMM(r,P,p0,theta_vec,Rini,iterEM,sigma_v_sq);
        west = inv(Rest+sigma_v_sq*eye(Npulse))*s_doppler;
        
        Rest_clair = (Xmat*Xmat')/L;  %Noiseless clutter snapshopts at CUT power level
        wclair = inv(Rest_clair+sigma_v_sq*eye(Npulse))*s_doppler;
        
        Rest_Tyler = cov_mat_est_Tyler(r,eye(Npulse),20);
        %Rest_Tyler = Rest_Tyler/trace(Rest_Tyler)*Npulse*(CNR+sigma_v_sq);
        wTyler = inv(Rest_Tyler)*s_doppler;
        
        %SCNR calculations
        dum = Rc + sigma_v_sq*eye(Npulse);
        SCNR_est   = SNR*abs(west'*s_doppler)^2 / real(west'*dum*west);
        SCNR_clair = SNR*abs(wclair'*s_doppler)^2 / real(wclair'*dum*wclair);
        SCNR_Tyler = SNR*abs(wTyler'*s_doppler)^2 / real(wTyler'*dum*wTyler);
        if isempty(SCNR_max)==true, SCNR_max = SNR*real(s_doppler'*inv(dum)*s_doppler); end;
        
        SCNRmat(ind_L,indMC,:) = [SCNR_max SCNR_clair SCNR_est SCNR_Tyler];
    end;
    writetime,
    disp(['Target vel. = ' num2str(target_vel) 'm/sec, L = ' num2str(L) ', Npulse = ' num2str(Npulse) ]);
    meanSCNRmat(ind_L,:)  = mean(squeeze(SCNRmat(ind_L,:,:)),1);
    
    figure(1), 
    plot(Lvec(1:ind_L),10*log10(meanSCNRmat(1:ind_L,:)),'o-');
    drawnow,
    waitbar(ind_L/length(Lvec),h),
end;
close(h)
%%
figure(1), 
plot(Lvec,10*log10(meanSCNRmat(:,1)),'-'); hold on; set(gca,'fontsize',12)
plot(Lvec,10*log10(meanSCNRmat(:,2)),'--'); 
plot(Lvec,10*log10(meanSCNRmat(:,3)),'-o'); 
plot(Lvec,10*log10(meanSCNRmat(:,4)),'-sq'); 
hold off
xlabel('L (number of snapshots)'); 
ylabel('output SCNR (dB)'); 
title(['SNR = ' num2str(SNR_dB - 10*log10(Npulse)) ' dB, N = ' num2str(Npulse) ', Target Velocity = ' num2str(target_vel) ' m/sec' char(10) ...
       'CNR = ' num2str(CNR_dB) ' dB, \mu_c = ' num2str(clutter_mean_vel) ' m/sec' ...
       ', \sigma_c = ' num2str(clutter_sigmav) ' m/sec'   ]);
legend('Max. SCNR Bound', 'Clairvoyant', 'EM (proposed)', 'Tyler''s','location','SouthEast'); 
grid on