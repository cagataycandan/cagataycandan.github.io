set(0, 'DefaultLineLineWidth', 2);
rng('shuffle');  %Seed is randomized
paperfig___SCNR_vs_Target_Vel; saveas(gcf, '../results/fig1.png');
paperfig___SCNR_vs_L; saveas(gcf, '../results/fig2.png');
paperfig___SCNR_vs_L_KdistClutter; saveas(gcf, '../results/fig3.png');

str1 = sprintf('\n*\n**\n*** Monte Carlo run is completed\n---> Please check fig1.png, fig2.png,fig3.png on the right pane <---');
disp(str1)




