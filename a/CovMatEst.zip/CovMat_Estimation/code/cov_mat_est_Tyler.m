function Rest = cov_mat_est_Tyler(r,Rest,maxiter)
[N,L] = size(r); 

if exist('Rest')==0, Rest = eye(N); end; 
if exist('maxiter')==0, maxiter = 20; end; 

iter = 1;
while (iter<=maxiter),
    Restinv = inv(Rest);
    dum = Restinv*r;
    dum = real(sum(conj(r).*dum)); %r'*inv(Rest)*r
    dum = bsxfun(@times,r,1./dum);
    Rest = dum*r';
    %Rest = Rest./sum(diag(Rest))*N;
    Rest = Rest*N/L;
        
    iter = iter + 1; 
end;
