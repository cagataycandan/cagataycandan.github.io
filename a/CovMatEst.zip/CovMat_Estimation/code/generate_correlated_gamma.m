function out = generate_correlated_gamma(nu,rho,L,S)
%Generates unit mean value, gamma dist. L random variables with correlation coefficient
%sequence corr-coef(k) = rho^|k|,
%
%Inputs:
% nu: shape parameter
% rho: correlation coefficient between two consecutive samples
% L: number of random variables generated
% S: number of L length vectors (default = 1)
%
%Output:
% out: L x S dimensional matrix
%
%To check
%     nu = 3; rho = 0.8; L = 10; S = 100e3;  
%     zvec = generate_correlated_gamma(nu,rho,L,S);
%     mean_zvec = mean(zvec(:)),  %should be 1 (almost)
% 
%     Mhat = 1/S*zvec*zvec';
%     dum = mean(zvec,2); 
%     CovMat = Mhat - dum*dum';
%     rho_MC = CovMat(1,2:end)./CovMat(1,1:end-1) %should be rho (almost)
%
%

if nu~=floor(nu), disp 'Generate_correlated_gamma: Argument ''nu'' should be an integer.'; return; end; 
if exist('S')==0, S = 1; end; 
    
rho_vec = rho.^(0:(L-1));
normal_cor_vec = sqrt(rho_vec);
Mn = toeplitz(normal_cor_vec);
sqrtMn = sqrtm(Mn);
zvec = 0;
for thisnu = 1:nu,
    dum = 1/sqrt(2)*sqrtMn*(randn(L,S)+1i*randn(L,S));
    zvec = zvec + abs(dum).^2;
end;
out = 1/nu*zvec; 

