N=500;
select=20:119;
omega = 2*pi/8;
Npointvec=2:6;
dum = linspace(-0.20,0,21); dum2 = linspace(0,0.20,21);
alphavec = [dum dum2(2:end)]; 

betavec = 1 - alphavec;
n=0:N-1;
s=cos(omega*n);

h = figure(1); set(h,'Defaultaxesfontsize',12); set(h,'Defaulttextfontsize',12);

rmssignal = sqrt(mean(s.^2));
semilogy(betavec,rmssignal*ones(1,length(betavec)),'--','linewidth',2.5,'markersize',20); drawnow; hold all;

error = [];
for Npoint = Npointvec,
    alphaind = 0;
    for alpha = alphavec,
        out = digscale(s,1-alpha,Npoint);
        nout = -1 + (1:length(out));
        s2 = cos(omega*(1-alpha)*nout);
        e = s2-out;
        e = e(select);
        alphaind = alphaind + 1;
        error(alphaind) = sqrt(mean(e.^2));
    end;

error(error<1e-10) = 0; %Needed for beta=1, error is not zero due to round-off errors   
semilogy(betavec,error,'.-','linewidth',2.5,'markersize',20);  drawnow;   
end;
%%
title(['RMS error in the scaling of cos(\pi/4 n) by \beta' char (10) ...
        '(change of sampling rate by 1/\beta)']);
  
xlabel('\beta');
ylabel('Signal RMS and RMS Error');
dumstring={'Signal RMS', 'N = 2'  ,  'N = 3'  ...
         , 'N = 4'  ,  'N = 5' ,   'N = 6'};
legend(dumstring,'Location','NorthEast'); 
set(gca,'xtick',0.5:0.1:1.5)
grid on
hold off;

%print -depsc -f1 ../Latex/figs/figrmserror1.eps