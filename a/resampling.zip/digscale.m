function out = digscale(s,beta,Npoint) 
% function out = digscale(s,beta,Npoint) 
% Scales the input vector s by beta. 
%
% The operation is equivalent of out(t) = s(beta t) in discrete time
% The operation can be interpretted as the sampling rate 
%
% s      : input 
% beta   : scaling coefficient (beta = 1 - alpha) 
% Npoint : Number of points to be used Lagrange interpolation
% 
% out    : output 
%
% Cagatay Candan
% Jan. 2013
% 

if Npoint <= 0, disp ('Npoint should be at least 2'); return; end; 

alpha = 1 - beta; % alpha > 0 --> Higher Sampling Rate or sig. expands in time
                  % alpha < 0 --> Lower  Sampling Rate or sig. compresses
                     
N = length(s);                      
                  
if alpha>0,   %Upsampling 
  
    %Construct A and B (state model) 
    A = diag(ones(1,Npoint-1),-1);
    b = zeros(Npoint,1); b(1)=1;
    
    %Construct C1 for the output of differencing blocks
    C1 = zeros(Npoint,Npoint);
    dum = 1; C1(1,:)=[dum zeros(1,Npoint-1)];
    for dumind = 1:Npoint-1,
        dum = conv([1 -1],dum);
        C1(dumind+1,:)=[dum zeros(1,Npoint-1-dumind)];
    end;
    
    %Delay (Compensate Anti-Causal Part of Response)
    delay = floor((Npoint-2)/2); 
    x = zeros(Npoint,1); %Default Buffer Contents
    for input_index = 1: delay, %Fill Buffers "delay" number of times
        x = A*x + b*s(input_index); %State Model for buffer contents
    end;
    
    %
    output_index = 0; D = -alpha; 
    for input_index=delay+1:N,
        D = D + alpha; 
        output_index = output_index + 1; 
        
        if D > 1 + 100*eps, %Insert Extra Sample
            [coefvec,Dvec2]=construct_multipliers(Npoint,alpha,output_index-1); 
            out(output_index) = coefvec'*out_diff;  %Extra Sample without buffer update
%            coefvec'*C1;
            
            D = D + alpha - 1;
            output_index = output_index + 1; 
        end;

        x = A*x + b*s(input_index); %State Model for buffer contents
        out_diff = C1*x; %Output of differencing blocks
                
        [coefvec,Dvec2]=construct_multipliers(Npoint,alpha,output_index-1); 
%        coefvec'*C1,
        
        out(output_index) = coefvec'*out_diff; 
       

    end;
   
else %if alpha<0  %Downsampling
    
      %Construct A and B (state model) 
    A = diag(ones(1,Npoint-1),-1);
    b = zeros(Npoint,1); b(1)=1;
    
    %Construct C1 for the output of differencing blocks
    C1 = zeros(Npoint,Npoint);
    dum = 1; C1(1,:)=[dum zeros(1,Npoint-1)];
    for dumind = 1:Npoint-1,
        dum = conv([1 -1],dum);
        C1(dumind+1,:)=[dum zeros(1,Npoint-1-dumind)];
    end;
    
    %Delay (Compensate Anti-Causal Part of Response)
    delay = floor((Npoint-2)/2)+2; 
    x = zeros(Npoint,1); %Default Buffer Contents
    for input_index = 1: delay, %Fill Buffers "delay" number of times
        x = A*x + b*s(input_index); %State Model for buffer contents
    end;
    
    %
    
    output_index = 1;  
    out(1) = s(1); D = 0; 
    for input_index=delay+1:N,
        D = D - alpha; 
                
        x = A*x + b*s(input_index); %State Model for buffer contents
        out_diff = C1*x; %Output of differencing blocks
        
        if D > 1  - 100*eps, %Skip Sample
            D = D - 1 + alpha; 
            continue,            
        else
              [coefvec,Dvec2]=construct_multipliers(Npoint,alpha,output_index); 
%              coefvec'*C1,
              output_index = output_index + 1; 
              out(output_index) = coefvec'*out_diff; 
        end;
        
        
    end;%end of else 
end; %end of if alpha

%%%%%%%%
function [coefvec,Dvec2] = construct_multipliers(Npoint,alpha,n)
% Calculates the multipliers shown with d_i[n] in the manuscript
% 
% coefvec : multipliers d_i[n], 0 <= i <= Npoint -1
% Dvec2   : generated to verify the system  
%         :  fliplr(Dvec2) should be identical to Dvec 
%         %  calculated in the main function
%
% The output of this function is not used in the implementation given.
% The function is presented to verify the results of manuscript. 

if (alpha > 0), %upsampling
    if rem(Npoint,2) == 0,  %Npoint : Even
        D =  - ((Npoint - 2)/2 + rem(alpha*n,1+1500*eps)); 
    else  %Npoint : Odd
        D =  - ((Npoint - 3)/2 + rem(alpha*n,1+1500*eps)); 
    end;
else %alpha <0, downsampling
    if rem(Npoint,2) == 0,  %Npoint : Even
        D =  - ((Npoint - 2)/2 + rem((1+alpha)*n,1+1500*eps));
    else  %Npoint : Odd
        D =  - ((Npoint - 3)/2 + rem((1+alpha)*n,1+1500*eps));
    end;
end;
    
coefvec = zeros(Npoint,1);
coefvec(1) = 1; diffblock{1}=1; 
for ii=1:Npoint-1, 
    coefvec(ii+1) = coefvec(ii)/ii * (D + ii-1); 
    diffblock{ii+1} = conv([1 -1],diffblock{ii});
end;

Dvec2 = zeros(1,Npoint);
for ii=1:Npoint, 
    Dvec2 = Dvec2 + ... 
        coefvec(ii)*[diffblock{ii} zeros(1, Npoint-length(diffblock{ii}))];
end;


