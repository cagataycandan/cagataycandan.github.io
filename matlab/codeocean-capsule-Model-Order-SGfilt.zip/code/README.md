# Model Order Selection for Savitzky–Golay Filtering via N-fold Cross-Validation

This capsule reproduces the numerical results in the paper titled **Model Order Selection for Savitzky–Golay Filtering via N-fold Cross-Validation** by Cagatay Candan submitted to Elsevier Signal Processing journal in April 2025. 

To execute, press <span style="background-color:#335eff ">*Reproducible Run*</span> button on your right. This executes `run.sh`, a shell script calling MATLAB to start a Monte Carlo experiment identical to the ones given in Figures 2 and 3 of the paper. 

To change the Monte Carlo experiment parameters, click on `compareCV_with_BIC_wrt_N.m` or `compareCV_with_BIC_wrt_noisevar.m` in the `/code` pane (the left pane). By changing first 4 lines of these .m files, you can implement different comparisons. Once Monte Carlo run is completed, you can see the results by clicking on figNumRes_N.png or figNumRes_SNR.png links on the right pane. 

## Included Materials

In the `/code` pane, in addition to this readme, you will find:

* `SGorderCV.m`, main file implementing the suggested method
* `SGorderBIC.m`, file implementing BIC-N and BIC-SNR methods 
* `compareCV_with_BIC_wrt_N.m`, implements comparisons with fixed noise variance for increasing sample size (N)
* `compareCV_with_BIC_wrt_noisevar.m`, implements comparisons with fixed sample (N) for decreasing noise variance 
* `legendstr.m`, utility function for legend formating  

### Version history
* v1.0 Initial submission 

### Author
Cagatay Candan

<https://cagataycandan.github.io/>