function [bestorder_BICSNR, bestorder_BICN] = SGorderBIC(data,max_poly_order,Q)
% function [bestorder_BICSNR, bestorder_BICN] = SGorderBIC(data,max_poly_order,Q)
% 
% Returns best Savitzky-Golay filtering model order according to BIC rule
%
% Inputs: 
%    data : 1 x N dimensional input
%    max_poly_order : Desired maximum degree for SG filtering 
%                     (should be less than N-1)  
%    Q    : QR decomposition for Amat involved (runs faster if provided,
%                                               otherwise calculated)
%
% Output: 
%    bestorder_BICSNR : selected over by BIC-SNR rule 
%    bestorder_BICN   : selected over by BIC-N rule 
%
% 
% Reference: 
%   P. Stoica, P. Babu, On the Proper Forms of BIC for Model Order Selection, IEEE
%   Trans. Signal Process. 60 (9) (2012) 4956–4961. doi:10.1109/TSP.2012.2203128.
% 
% Cagatay Candan
% April 2025
%

data = data(:);
N = length(data);   % N : length of SG filter / window length

if N <= max_poly_order+1
    disp 'SGorderCV.m: Filter length (length(data)) should be bigger than max_poly_order+1 (number of coeff. in max_poly_order polynomial).';
    return;
end

Nhalf = round((N-1)/2);  % datalength = 5 --> Dhalf = 2;  dvec = [-2 -1 0 1 2]
% datalength = 4 --> Dhalf = 2;  dvec = [-2 -1 0 1]

if nargin==2 %QR factorization, if Q is not provided
    %Generate Amat
    Amat = zeros(max_poly_order+1,N);
    Amat(1,:) = ones(1,N);
    dvec = -Nhalf:(-Nhalf+N-1);      %dvec
    for thisrow = 2:max_poly_order+1
        Amat(thisrow,:)  = Amat(thisrow-1,:) .*dvec;
    end
    %%%%%%%%%%%
    [Q,~] = qr(Amat');
end

projectedinput = zeros(N,1); BIC_SNRv = zeros(max_poly_order+1,1);
for thispolyorder = 0:max_poly_order
    ind = thispolyorder + 1;
    dum = Q(:,ind);
    projectedinput = projectedinput + dum*(dum'*data);

    epsilon_s =  projectedinput - data;
    sigmai_sq = sum(epsilon_s.^2)/N;
    if sigmai_sq < 1,
        BIC_SNRv(ind) = (N - thispolyorder - 2)*log ( sigmai_sq );
    else
        BIC_SNRv(ind) = N*log ( sigmai_sq );
    end

    BIC_Nv(ind) = (thispolyorder+1)^2*log(N) + N*log(sigmai_sq);

end
%toterror_polyorders,

[~,bestone] = min(BIC_SNRv); bestorder_BICSNR = bestone - 1;
[~,bestone] = min(BIC_Nv); bestorder_BICN = bestone - 1;