Nvec = 6:2:30;
noise_var = 1;
myfunc = @(tvec)  0.01*tvec.^3 + 1; trueorder = 3; %cubic
MCnum = 1000;

stats = zeros(length(Nvec),3); loopind = 0;
for thisN = Nvec
    N = thisN; max_poly_order = N-2;
    tvec = -N/2:N/2-1;

    s = myfunc(tvec);

    figure(1), %See a single realization
    dum = linspace(min(tvec)-1,max(tvec)+1,500);
    plot(dum, myfunc(dum)); hold on;
    plot(tvec,s,'o');
    plot(tvec,s + sqrt(noise_var)*randn(size(tvec)),'*');
    hold off;
    
    [~,Q] = SGorderCV(1:N,max_poly_order); %just to jet Q matrix!
    bestCVorder_vec = zeros(MCnum,1); BICSNRorder_vec = zeros(MCnum,1); BICNorder_vec = zeros(MCnum,1); 
    for thisMC = 1:MCnum,
        data = s + sqrt(noise_var)*randn(size(tvec));
        bestCVorder_vec(thisMC) = SGorderCV(data,max_poly_order,Q);
        [BICSNRorder_vec(thisMC), BICNorder_vec(thisMC)] = SGorderBIC(data,max_poly_order,Q);
    end;

    figure(2),[binval_CV,bincenter] = hist(bestCVorder_vec,0:max_poly_order+2); hist(bestCVorder_vec,0:max_poly_order+2); title(['CV, noise-var = ' num2str(noise_var)]);
    figure(3), binval_BICSNR = hist(BICSNRorder_vec,0:max_poly_order+2);  hist(BICSNRorder_vec,0:max_poly_order+2);  title(['BIC-SNR, noise-var = ' num2str(noise_var)]);
    figure(4), binval_BICN = hist(BICNorder_vec,0:max_poly_order+2);  hist(BICNorder_vec,0:max_poly_order+2);  title(['BIC-N, noise-var = ' num2str(noise_var)]);
    [bincenter; binval_CV/MCnum; binval_BICSNR/MCnum; binval_BICN/MCnum]

    loopind = loopind+1;
    stats(loopind,:) =  [binval_CV(trueorder+1) binval_BICSNR(trueorder+1) binval_BICN(trueorder+1)]./MCnum;

end
%%
figure(5),
stats,
plot(Nvec,stats(:,1),'o-');  hold on
plot(Nvec,stats(:,2),'sq--');
plot(Nvec,stats(:,3),'d-.'); hold off;

title('\sigma_w^2 = 1');
legend('CV','BIC_{SNR}','BIC_{N}','Location','NorthWest');
xlabel('N (data size)');  ylabel('P(correct order selection)')
grid on;

set(gca,'fontsize',14)

return;
%%
% print -depsc -f5 '..\latex\Elsevier SP\eps-SG\fignumresN.eps'



