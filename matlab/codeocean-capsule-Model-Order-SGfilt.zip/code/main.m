set(0, 'DefaultLineLineWidth', 3);
rng('shuffle')

compareCV_with_BIC_wrt_N
saveas(gcf, '../results/figNumRes_N.png');

compareCV_with_BIC_wrt_noisevar
saveas(gcf, '../results/figNumRes_SNR.png');

disp 'Monte Carlo run is completed.';