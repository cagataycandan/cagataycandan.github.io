function [bestorder,Q] = SGorderCV(data,max_poly_order,Q)
%function [bestorder,Q] = SGorderCV(data,max_poly_order,Q)
%
% Returns best Savitzky-Golay filtering model order according to 
%                 N-fold Cross-Validation (leave-one-out cross-validation) 
%
% Inputs: 
%    data : 1 x N dimensional input
%    max_poly_order : Desired maximum degree for SG filtering 
%                     (should be less than N-1)  
%    Q    : QR decomposition for Amat involved (runs faster if provided,
%                                               otherwise calculated)
%
% Output: 
%    bestorder : Best order found by N-fold cross-validation
%    Q         : QR decomposition of Amat 
%                (N = 5, P = 3; (input length = 5, max_poly_order = 3)  
%                run 
%                  >> [~,Q] = SGorderCV(1:5,3) 
%                once and get Q matrix before Monte Carlo runs;  
%                then use Q matrix 
%                  >> bestorder = SGorderCV(data,3,Q) 
%                in the MonteCarlo loop.) 
%                   
%
% Cagatay Candan
% April, 2025
%

data = data(:);
N = length(data);   % N : length of SG filter / window length

if N <= max_poly_order+1
    disp 'SGorderCV.m: Filter length (length(data)) should be bigger than max_poly_order+1 (number of coeff. in max_poly_order polynomial).';
    return;
end

Nhalf = round((N-1)/2);  % datalength = 5 --> Nhalf = 2;  nvec = [-2 -1 0 1 2]
                         % datalength = 4 --> Nhalf = 2;  nvec = [-2 -1 0 1] 

if nargin==2 %QR factorization, if Q is not provided
    %Generate Amat
    Amat = zeros(max_poly_order+1,N);
    Amat(1,:) = ones(1,N);
    nvec = -Nhalf:(-Nhalf+N-1);      %dvec 
    for thisrow = 2:max_poly_order+1
        Amat(thisrow,:)  = Amat(thisrow-1,:) .*nvec;
    end
    %%%%%%%%%%%
    [Q,~] = qr(Amat');
end

projectedinput = zeros(N,1); diagMmat = zeros(N,1);
for thispolyorder = 0:max_poly_order
    ind = thispolyorder + 1;
    dum = Q(:,ind);
    projectedinput = projectedinput + dum*(dum'*data);
    diagMmat = diagMmat + dum.^2;

    epsilon_s =  projectedinput - data;          %smoothing  error vec. 
    epsilon_p = epsilon_s(:).*(1./(1-diagMmat)); %prediction error vec.
    tot_pred_error_sq(ind) = sum(epsilon_p.^2);
end
%toterror_polyorders,

[~,bestone] = min(tot_pred_error_sq);
bestorder = bestone - 1;
