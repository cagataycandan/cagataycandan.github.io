function str=legendstr(prefix,vec,postfix)
%function str=legendstr(prefix,vec,postfix)
%prepares a legend string
%
%Usage : 
% Simple: legend(legendstr('SNR=',1:5,' dB'))
% Not Simple: legend([legendstr('m=',mvec) {'Random Pick'} {'Monopulse'}]);
%
%Sept. 2010, 
%CC

if exist('prefix')==0,  prefix=''; end;
if exist('postfix')==0, postfix=''; end;
    
for k=1:length(vec);
    str{k}=[ prefix num2str(vec(k)) postfix];
end;