function out=setblock(I,num,newblock),
% function out=getblock(I,num)
% changes the block number of ``num'' of ``I'' to ``newblock''
% 
% oct 30, 2002.
% CC
%

[bRow, bCol]=size(newblock);

[M,N]=size(I); 
blocks_in_a_col=ceil(M/bRow); 

block_row=rem(num,blocks_in_a_col); 
block_col=floor(num/blocks_in_a_col)+1;

if block_row==0, block_row=blocks_in_a_col; block_col=block_col-1;end;

out=set_matrix(I,((block_row-1)*bRow+1):(block_row*bRow),((block_col-1)*bCol+1):(block_col*bCol),newblock);