/*
 * 

READS THE ENCODED TRANSFORM COEFFICIENTS AND THE QUANTIZATION TABLE FROM A JPG FILE
Modified from WJPG.C

USAGE:  [coef,quant]=read_coef('lena90.jpg');
June 2002, 
CC


TO COMPILE:  mex read_coef.c C:\CANDAN\Watermarking\Stirmark\src\JPEGLib\debug\jpeglib.lib 
                       at MATLAB V12 command prompt

 
 
********** 
 *WJPGC.C 
 *
 * 
 *
 * 
 * This is a mex interface to the Independent Jpeg Group's (IJG)
 * LIBJPEG libaray.  This can write RGB and grayscale JPEG images.
 * 
 * The syntaxes are:
 *    
 *    
 *      wjpgc(RGB, filename);
 *      wjpgc(GRAY, filename);
 *      wjpgc(... , quality);
 * 
 * RGB is either a mxnx3 uint8 array containing a 24-bit image to
 * be stored in the jpeg file filename or a mxn uint32 array with 
 * each 4 bytes being RGBA, were A is currently garbage (maybe Alpha
 * in the future).
 *       
 * GRAY is a mxn uint8 array containing a grayscale image to
 * be stored in the jpeg file filename.    
 * 
 * The quality argument specifies the compression scheme's quality
 * setting which adjusts the tradeoff between image quality and
 * file-size. 
 * 
 * 
 * KNOWN BUGS:
 * -----------
 *
 * ENHANCEMENTS UNDER CONSIDERATION:
 * ---------------------------------
 * 
 * 
 * The IJG code is available at:
 * ftp://ftp.uu.net/graphics/jpeg/jpegsrc.v6.tar.gz
 * 
 * Chris Griffin, June 1996
 * Copyright (c) 1984-98 by The MathWorks, Inc.
 * $Revision: 1.6 $  $Date: 1998/02/19 16:29:25 $
 */



#include "mex.h"
#include <stdio.h>
#include <setjmp.h>
#include "D:\Watermarking\Stirmark\src\JPEGLib\jpeglib.h"

#define RGB_IMG          0
#define GRAY_IMG         1
#define PACKED_RGB_IMG   2

/* 
 *  These guys are to replace specific routines in the jpeg library's
 *  jerror.c module. 
 */

static void my_error_exit (j_common_ptr cinfo);
static void my_output_message (j_common_ptr cinfo);

struct my_error_mgr {
  struct jpeg_error_mgr pub;	/* "public" fields */
  jmp_buf setjmp_buffer;	/* for return to caller */
};

typedef struct my_error_mgr * my_error_ptr;


void mexFunction(int nlhs, mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]) 
                 
{  
    struct jpeg_decompress_struct srcinfo;
    
    char *filename;    
    FILE * infile;		/* source file */    
    long strlen;    
    jvirt_barray_ptr *src_coef_arrays;
    double *out,*quant_table;
    struct my_error_mgr jerr;
    int dims[2];
    
    int row,col,count;
    
  
    if(! mxIsChar(prhs[0]))
    {
        mexErrMsgTxt("Second argument is not a string.");
    }

    strlen = mxGetM(prhs[0]) * mxGetN(prhs[0]) + 1;
    filename = (char *) mxCalloc(strlen, sizeof(*filename));
    mxGetString(prhs[0],filename,strlen);  /* First argument is the filename */
    

 if ((infile = fopen(filename, "rb")) == NULL) {
    mexErrMsgTxt("can't open file");
  }    
  
  
    srcinfo.err = jpeg_std_error(&jerr.pub);
    jerr.pub.output_message = my_output_message;
    jerr.pub.error_exit = my_error_exit;
    if(setjmp(jerr.setjmp_buffer))
    {
        /* If we get here, the JPEG code has signaled an error.
         * We need to clean up the JPEG object, close the input file, 
         * and return.
         */
        jpeg_destroy_compress(&srcinfo);
        fclose(infile);
        return;
    }
  
    
   
   jpeg_create_decompress(&srcinfo);    

   jpeg_stdio_src(&srcinfo, infile);        
     
   (void) jpeg_read_header(&srcinfo, TRUE);

   src_coef_arrays = jpeg_read_coefficients(&srcinfo);
 
   

   
plhs[0] = mxCreateDoubleMatrix(srcinfo.image_height,srcinfo.image_width, mxREAL); 
plhs[1] = mxCreateDoubleMatrix(8,8, mxREAL); 

/**********
dims[0]=srcinfo.image_height; dims[1]=srcinfo.image_width;
plhs[0] = mxCreateNumericArray(2,dims,mxINT16_CLASS,mxREAL); 
************/
 out = mxGetPr(plhs[0]);  
 quant_table = mxGetPr(plhs[1]);

{
  j_decompress_ptr srcinfo2;
  JDIMENSION blk_y;
  JDIMENSION dst_blk_x;
  int i;
  JBLOCKARRAY buffer;
  jpeg_component_info *compptr;
  JBLOCKROW src_row_ptr;  
  JCOEFPTR src_ptr;
 
    srcinfo2= &srcinfo;
    compptr = srcinfo2->comp_info;

    
/* 1 = compptr->v_samp_factor     */
    for (blk_y = 0; blk_y < compptr->height_in_blocks;
	 blk_y += 1 ) 
    { 

 	  buffer = (*srcinfo2->mem->access_virt_barray)
	  ((j_common_ptr) srcinfo2, src_coef_arrays[0], blk_y,
	   (JDIMENSION) 1 , FALSE);	  
	  
      src_row_ptr=buffer[0];
      
      for (dst_blk_x = 0; dst_blk_x < compptr->width_in_blocks;
	       dst_blk_x++) {

	        src_ptr = src_row_ptr[dst_blk_x];

	        

             for (count=0, row=0; row<8; row++) {
                 for (col=0; col<8; col++) {
 *(out+(col+8*dst_blk_x)*srcinfo.image_height+row+blk_y*8) = (double) src_ptr[count]; 
        count++;
        }
    }


	        
/**********
           for (i = 0; i < DCTSIZE2; i++) {
            *out++= (double) src_ptr[i];
     printf("\n%f",(double) src_ptr[i]);    
       printf("\n%f",out[i]); 
       printf("\n%f", (double) compptr->quant_table->quantval[i]);     
         
          }
***********/

/**** printf("\n%d---%d", blk_y,dst_blk_x);          *****/
  } /*for dst_blk */
} /*for blk_y */

/********GET QUANTIZATION TABLE**********************/
for (count=0, row=0; row<8; row++) {
        for (col=0; col<8; col++) {
        *(quant_table+col*8+row)= (double) compptr->quant_table->quantval[count];
        count++;
        }
}
/******************************************************/

}


  (void) jpeg_finish_decompress(&srcinfo);
  jpeg_destroy_decompress(&srcinfo);

}



static void
my_error_exit (j_common_ptr cinfo)
{
  /* cinfo->err really points to a my_error_mgr struct, so coerce pointer */
  my_error_ptr myerr = (my_error_ptr) cinfo->err;

  /* Always display the message. */
  /* We coulD postpone this until after returning, if we chose. */
  (*cinfo->err->output_message) (cinfo);

  /* Return control to the setjmp point */
  longjmp(myerr->setjmp_buffer, 1);
}


/* 
 *  Here's the routine to replace the standard output_message method:
 */


static void
my_output_message (j_common_ptr cinfo)
{
  char buffer[JMSG_LENGTH_MAX];

  /* Create the message */
  (*cinfo->err->format_message) (cinfo, buffer);

  /* Send it to stderr, adding a newline */
  mexWarnMsgTxt(buffer);
}