function out=parse_fields(line)
%function out=parse_fields(line)
% PARSES OUT THE DATA/FIELDS SEPARATED BY SPACES 
% 
% IT MAY KILL SOME CHARACTERS OTHER THAN SPACE
% ALWAYS CHECK THAT IT IS DOING WHAT YOU WANT
% 
% CHEERS, 
% CC, Feb, 18, 2002
%

set_of_chars=[ abs('a'):abs('z') abs('A'):abs('Z') abs('0'):abs('9') abs(['.' ',']) abs(['>' '<'])];

word=[];out_index=0; k=1;
while (k~=length(line)),
    if ismember(line(k),set_of_chars),
        word=[word line(k)];
        else
            if length(word)>0,   % I HAVE SOMETHING TO SAY
                out_index=out_index+1; 
                out(out_index) = {word};
                word=[];    % THANKS 
            end;
        end;
k=k+1;
end;    