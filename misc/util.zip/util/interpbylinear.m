function out=interpbylinear(in,factor);
%function out=interpbyrect(in,factor);
%
% Linear interpolation of vector "in"
% by ``factor" 
%
%Sept. 2011
%CC

if factor<=0, disp('Factor parameter should be > 0'); return; end;

columninput=0;
if size(in,2)==1, columninput=1; in=in.'; end;

out=[in; zeros(factor-1,length(in))];
out=out(:);

filt=1:-1/factor:1/factor
filt=[fliplr(filt(2:end)) filt];
out = conv(out,filt);
out=out(factor:length(out)-factor+1),


if columninput==0, out=out(:).'; end;