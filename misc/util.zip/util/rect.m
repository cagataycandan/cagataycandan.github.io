function out=rect(x,N,M)
%function out=rect(x,N,M)
%out = 1 if  N<=x<=M
%M not defined =< M=inf is assumed
%
%Sept 2002, 
%CC
%
if nargin==1, M=inf; end;

out = (x >= N) & (x <=M);

