function out=blockfliplr(I,N)
%Blockwise fliplr operation
% x=[ A B C D]
% blockfliplr(x,2) => [C D A B]
%
%Oct 8, 2001
%CC

M=size(I,2);

if (rem(M,N)~=0), disp ('N should be a divisor of number of columns of I'); return; end;

out=zeros(size(I));
for k=1:N, 
   dum=I(:,k:N:M);
   out(:,k:N:M)=fliplr(dum);
end;


