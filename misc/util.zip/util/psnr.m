function out=psnr(a1,a2);
%calculates psnr
%
if ~strcmp(class(a1),'double'), a1=double(a1); end;
if nargin==2, 
if ~strcmp(class(a2),'double'), a2=double(a2); end;    
   a1=a1-a2;
end;

out = 20*log10(255/norm(a1,'fro')*sqrt(prod(size(a1))));