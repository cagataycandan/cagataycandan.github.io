function out=set_matrix(matrix,row_vec,col_vec,value)
%function out=set_matrix(matrix,row_vec,col_vec,value)
%
%
% sets matrix(every element of row_vec, every element of col_vec ) to value
% matlab does not allow that 
%
% row_vec, col_vec can be in 1's and 0's or can be integers explicitly 
%                                           stating row, column numbers
%
% july 2002, 
% CC
%

if any(row_vec==0), row_vec=find(row_vec>0); end;

if length(value)==1, value=ones(length(row_vec),length(find(col_vec>0)))*value; end;
    
out=matrix; counter=0;
for rr=row_vec,
    counter=counter+1;
    out(rr,col_vec)=value(counter,:);
end;