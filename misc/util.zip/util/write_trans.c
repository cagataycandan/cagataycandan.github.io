/*

WRITE TRANSFORM COEFFICIENTS TO A JPEG FILE

write_trans(new_coef,'in.jpg','out.jpg');
creates an out.jpg file 
    with the headers and quantization tables of in.jpg 
but
    replaces the transform coefficients of in.jpg with new_coef matrix.

    
MODIFIED FROM: WJPGC.C
RELATED TO: READ_TRANS.C 

JUNE 2002, 
CC

* WJPGC.C 
 *
 * This is a mex interface to the Independent Jpeg Group's (IJG)
 * LIBJPEG libaray.  This can write RGB and grayscale JPEG images.
 * 
 * The syntaxes are:
 *    
 *    
 *      wjpgc(RGB, filename);
 *      wjpgc(GRAY, filename);
 *      wjpgc(... , quality);
 * 
 * RGB is either a mxnx3 uint8 array containing a 24-bit image to
 * be stored in the jpeg file filename or a mxn uint32 array with 
 * each 4 bytes being RGBA, were A is currently garbage (maybe Alpha
 * in the future).
 *       
 * GRAY is a mxn uint8 array containing a grayscale image to
 * be stored in the jpeg file filename.    
 * 
 * The quality argument specifies the compression scheme's quality
 * setting which adjusts the tradeoff between image quality and
 * file-size. 
 * 
 * 
 * KNOWN BUGS:
 * -----------
 *
 * ENHANCEMENTS UNDER CONSIDERATION:
 * ---------------------------------
 * 
 * 
 * The IJG code is available at:
 * ftp://ftp.uu.net/graphics/jpeg/jpegsrc.v6.tar.gz
 * 
 * Chris Griffin, June 1996
 * Copyright (c) 1984-98 by The MathWorks, Inc.
 * $Revision: 1.6 $  $Date: 1998/02/19 16:29:25 $
 */



#include "mex.h"
#include <stdio.h>
#include <setjmp.h>
#include "jpeglib.h"

#define RGB_IMG          0
#define GRAY_IMG         1
#define PACKED_RGB_IMG   2

/* 
 *  These guys are to replace specific routines in the jpeg library's
 *  jerror.c module. 
 */

static void my_error_exit (j_common_ptr cinfo);
static void my_output_message (j_common_ptr cinfo);

struct my_error_mgr {
  struct jpeg_error_mgr pub;	/* "public" fields */
  jmp_buf setjmp_buffer;	/* for return to caller */
};

typedef struct my_error_mgr * my_error_ptr;


void mexFunction(int nlhs, mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]) 
                 
{  
    struct jpeg_decompress_struct srcinfo;    
    struct jpeg_compress_struct dstinfo;
    
    struct jpeg_error_mgr jsrcerr, jdsterr;
    
    char *filename;    
    FILE * infile;		/* source file */    
    FILE * outfile;
    

    jvirt_barray_ptr *src_coef_arrays;
    jvirt_barray_ptr * dst_coef_arrays = NULL;

    j_decompress_ptr srcinfo2;
    jpeg_component_info *compptr;
    
    JBLOCKARRAY buffer;
    JBLOCKROW dst_row_ptr;  
    JCOEFPTR dst_ptr;    
    JDIMENSION blk_y;
    JDIMENSION dst_blk_x;
    
    
    long strlen;        
    double *out,*quant_table;
    struct my_error_mgr jerr;
    int dims[2];
    
    int row,col,count;
    
/************OPEN INPUT FILE ******************/
    if(! mxIsChar(prhs[1]))
    {
        mexErrMsgTxt("Second argument is not a string.");
    }

    strlen = mxGetM(prhs[1]) * mxGetN(prhs[0]) + 1;
    filename = (char *) mxCalloc(strlen, sizeof(*filename));
    mxGetString(prhs[1],filename,strlen);  
  
 if ((infile = fopen(filename, "rb")) == NULL) {
    mexErrMsgTxt("can't open file");
  }    
  

/************OPEN OUTPUT FILE ******************/  
    if(! mxIsChar(prhs[2]))
    {
        mexErrMsgTxt("Third argument is not a string.");
    }

    strlen = mxGetM(prhs[2]) * mxGetN(prhs[0]) + 1;
    filename = (char *) mxCalloc(strlen, sizeof(*filename));
    mxGetString(prhs[2],filename,strlen);  
  
 if ((outfile = fopen(filename, "wb")) == NULL) {
    mexErrMsgTxt("can't write to the file");
  }    
  
  
  
  
  
    srcinfo.err = jpeg_std_error(&jerr.pub);
    jerr.pub.output_message = my_output_message;
    jerr.pub.error_exit = my_error_exit;
    if(setjmp(jerr.setjmp_buffer))
    {
        /* If we get here, the JPEG code has signaled an error.
         * We need to clean up the JPEG object, close the input file, 
         * and return.
         */
        jpeg_destroy_compress(&srcinfo);
        fclose(infile);
        return;
    }
  
    
   /******CREATE DECOMPRESSION OBJECT ************/
   srcinfo.err = jpeg_std_error(&jsrcerr);
   jpeg_create_decompress(&srcinfo);
   
  
   /******CREATE COMPRESSION OBJECT ************/   
    dstinfo.err = jpeg_std_error(&jdsterr);
    jpeg_create_compress(&dstinfo);

    
   /***********PROCESS INPUT*****************************/
   jpeg_stdio_src(&srcinfo, infile);        
   (void) jpeg_read_header(&srcinfo, TRUE);
   src_coef_arrays = jpeg_read_coefficients(&srcinfo);

   
     
  /************PROCESS OUTPUT**********/
   jpeg_copy_critical_parameters(&srcinfo, &dstinfo);   
   jpeg_stdio_dest(&dstinfo, outfile);



   
   
   /***ALLOCATE THE VIRTUAL ARRAY FOR DESTINATION ***/
   srcinfo2= &srcinfo;
   compptr = srcinfo2->comp_info; 
   
   dst_coef_arrays = (jvirt_barray_ptr *)
      (*srcinfo2->mem->alloc_small) ((j_common_ptr) srcinfo2, JPOOL_IMAGE,
	sizeof(jvirt_barray_ptr));

   dst_coef_arrays[0] =  (*srcinfo2->mem->request_virt_barray)
	((j_common_ptr) srcinfo2, JPOOL_IMAGE, FALSE,
	 (JDIMENSION) compptr->width_in_blocks,
	 (JDIMENSION) compptr->height_in_blocks,
	 (JDIMENSION) 1);
	 
   (*srcinfo2->mem->realize_virt_arrays) ((j_common_ptr) srcinfo2);	 

 

   /**** GET NEW TRANSFORM COEFFICIENTS ****/
   out = mxGetPr(prhs[0]);

     
   
   
   /**** WRITE NEW COEFS TO VIRTUAL ARRAY ****/

   for (blk_y = 0; blk_y < compptr->height_in_blocks;
	 blk_y += 1 ) 
    { 
/*    printf("\n MEM ONCE - CAGATay %d---%d",blk_y,compptr->height_in_blocks);    */
   
    buffer = (*srcinfo2->mem->access_virt_barray)
	  ((j_common_ptr) srcinfo2, dst_coef_arrays[0], blk_y,
	   (JDIMENSION) 1 , TRUE);	  
/*   printf("\n MEM SONRA CAGATay %d---%d",blk_y,compptr->height_in_blocks);          	   */
      dst_row_ptr=buffer[0];
      
      for (dst_blk_x = 0; dst_blk_x < compptr->width_in_blocks;
	       dst_blk_x++) 
	       {
	        dst_ptr = dst_row_ptr[dst_blk_x];
      
                 for (count=0, row=0; row<8; row++) {
                    for (col=0; col<8; col++) {
                 dst_ptr[count] = (JCOEF) *(out+(col+8*dst_blk_x)*srcinfo.image_height+row+blk_y*8);
                 count++;
/*        printf("\n%f",out[count]);                   */
                    } /*for col */
                 }  /*for row*/


	        

/**** printf("\n%d---%d", blk_y,dst_blk_x);          *****/
  } /*for dst_blk */

  } /*for blk_y */





/************PUT IN NEW COEFFICIENTS**********/   
jpeg_write_coefficients(&dstinfo, dst_coef_arrays);	 


   
/*********FINISH***************/
jpeg_finish_compress(&dstinfo);
jpeg_destroy_compress(&dstinfo);
(void) jpeg_finish_decompress(&srcinfo);
jpeg_destroy_decompress(&srcinfo);

fclose(infile);
fclose(outfile);
}




static void
my_error_exit (j_common_ptr cinfo)
{
  /* cinfo->err really points to a my_error_mgr struct, so coerce pointer */
  my_error_ptr myerr = (my_error_ptr) cinfo->err;

  /* Always display the message. */
  /* We coulD postpone this until after returning, if we chose. */
  (*cinfo->err->output_message) (cinfo);

  /* Return control to the setjmp point */
  longjmp(myerr->setjmp_buffer, 1);
}


/* 
 *  Here's the routine to replace the standard output_message method:
 */


static void
my_output_message (j_common_ptr cinfo)
{
  char buffer[JMSG_LENGTH_MAX];

  /* Create the message */
  (*cinfo->err->format_message) (cinfo, buffer);

  /* Send it to stderr, adding a newline */
  mexWarnMsgTxt(buffer);
}