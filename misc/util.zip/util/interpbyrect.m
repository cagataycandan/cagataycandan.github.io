function out=interpbyrect(in,factor);
%function out=interpbyrect(in,factor);
%
%Repeats every element of vector "in"
% by ``factor" times (Upsampling by rect. function)
%
%Sept. 2011
%CC

if factor<=0, disp('Factor parameter should be > 0'); return; end;

columninput=0;
if size(in,2)==1, columninput=1; in=in.'; end;

out=repmat(in,factor,1); out=out(:);

if columninput==0, out=out(:).'; end;