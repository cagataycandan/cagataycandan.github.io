function [] = prpoly(num,tvar)
%PRINTpolynomial 
%	Stolen from printsys!!
%	Clay M. Thompson  7-23-90
%	Copyright (c) 1986-93 by the MathWorks, Inc.

dlen=1;
if nargin==1,  tvar = 'x'; end;
  [nn,mn] = size(num);
  for i=1:nn,
    [t,nlen] = poly2str(num(i,:),tvar);

    % Now print the polynomials
    len=max([dlen,nlen])-3;
    disp(' ')
    if nn==1,
      disp('polynomial = ')
    else
      disp(['num(',int2str(i),')/den = '])
    end
    disp(' ')
    if length(t)<len+3,		% Print numerator
      disp([' '*ones(1,(len+4-length(t))/2),t]),
    else
      disp(t)
    end
  end




 