function givemepix(str1,str2,str3)

%set(gcf,'WindowButtonDownFcn',' a=ceil(get(gca,''currentpoint'')); title( [num2str(a(1,2:-1:1)) '' value='' num2str(R3(a(1,2),a(1,1)))]);');

msg = 'a=round(get(gca,''currentpoint'')); title( [num2str(a(1,2:-1:1)) '' value='' num2str(';
msg = [msg str1 '(a(1,2),a(1,1)))'];


if nargin>1,
   msg = [msg ' '' xxx '' num2str(' str2 '(a(1,2),a(1,1)))'];
end

if nargin>2,
   msg = [msg ' '' xxx '' num2str(' str3 '(a(1,2),a(1,1)))'];
end

msg = [msg ']);rbbox([get(gcf,''currentpoint'') 0 0],get(gcf,''currentpoint''));ones;b=ceil(get(gca,''currentpoint''));corners=[a(1,2:-1:1); b(1,2:-1:1)]'];

disp (msg)
%set(gcf,'WindowButtonDownFcn','a=ceil(get(gca,''currentpoint'')); title( [num2str(a(1,2:-1:1)) '' value='' num2str(''str''(a(1,2),a(1,1)))]);,rbbox([get(gcf,''currentpoint'') 0 0],get(gcf,''currentpoint''));ones;b=ceil(get(gca,''currentpoint''));corners=[a(1,2:-1:1); b(1,2:-1:1)]');
set(gcf,'WindowButtonDownFcn',msg);