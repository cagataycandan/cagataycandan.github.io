function flist=topten(dirname,flist)

if nargin==1
    s.name = '';s.date='';s.bytes=0;s.isdir=false;
    for ii=1:10, flist(ii) = s; end
end

files = dir(dirname);
for ii=1:length(files)
%    files(ii)
    if files(ii).isdir && ~strcmp(files(ii).name,'.') && ~strcmp(files(ii).name,'..')
        flist = topten([dirname '\' files(ii).name],flist);
    else
        if files(ii).bytes>flist(10).bytes
            files(ii).name = [dirname '\' files(ii).name];
            flist = add2list(flist,files(ii));
        end
    end
end

function flist=add2list(flist,fnew)

for ii=1:10, byteslist(ii) = flist(ii).bytes; end
idx = max(find(byteslist>fnew.bytes));
if isempty(idx)
    idx=0;
end
flist(idx+2:10) = flist(idx+1:9);
flist(idx+1) = fnew;
