function mat2latex(matrix, places)
%function mat2latex(matrix, places)
%
%returns input matrix in latex importable format
%
%Sept.03
%CC
%

if nargin==1, places=2; end;

for k=1:size(matrix,1),
    str=[];
    for l=1:(size(matrix,2)-1),
        str=[str num2str(round(matrix(k,l)*10^places)/10^places) ' & '];
    end;
    str=[str num2str(round(matrix(k,l+1)*10^places)/10^places) ' \\'];
    disp(str);
end;

        
        
        