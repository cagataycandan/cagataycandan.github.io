function out=even(num);
%returns 1 when num is even, 0 otherwise. 
%

out=~rem(num,2);
