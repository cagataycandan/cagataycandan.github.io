function out = downbyn(in,byn)

out=in(1:byn:end,1:byn:end);
