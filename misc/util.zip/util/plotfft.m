function out=plotfft(input,format,times_p,plotstring)
%plotfft(input,format,times_p,plotstring)
%
%Plots magnitude spectrum of input
%input: vector, output=fft(input,N);
%times: scalar, (default value = 1)
%
%Number of fft points taken: length(input)*times
%
%Oct.2005
%CC
%

if exist('plotstring')==0,plotstring='b'; end;
if exist('times_p')==0, times_p=1; end;
if length(times_p)==0, times_p=1; end;

N = length(input)*times_p;    

out = fft(input,N);
if nargin>=2 & length(format)==2 & all(lower(format)=='db')==1
    out = max(-100,db(abs(out),'voltage'));
    plot(linspace(-pi,pi,N),fftshift(out));
    ylabel('Magnitude Spectrum (dB)');
else
   plot(linspace(-pi,pi,N),fftshift(abs(out)),plotstring);
   ylabel('Magnitude Spectrum (linear)');
end;

xlabel('Discrete frequency (rad/sample)');

q=axis; q(1:2)=[-pi pi];
axis(q);
set(gca,'Xtick',[-pi -pi*3/4 -pi/2 -pi/4 0 pi/4 pi/2 3/4*pi pi])
set(gca,'Xticklabel',{'-pi';'-3/4pi';'-pi/2';'-pi/4'; '0'; 'pi/4'; 'pi/2'; '3/4pi'; 'pi'})

if nargout==0, out=[]; end;