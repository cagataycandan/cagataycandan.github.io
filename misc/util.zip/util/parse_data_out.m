function out = parse_data_out

out=zeros(1,20);

fid=fopen('after_comp_01_20_LOG.txt');
message = char(fread(fid,15624))';
fclose(fid);

iter = 1;
%CUT JUNK OUT
while ( ~strcmp( message(iter:iter+3), 'TEST') )
    iter =iter+1;
end

% SKIP EVERYTHING UNTIL NEW LINE
while (abs(message(iter))~=10), iter=iter+1; end;
iter=iter+1;

% SKIP EVERYTHING UNTIL NEW LINE
while (abs(message(iter))~=10), iter=iter+1; end;
iter=iter+1;

data_out=1;
% NOW START PROCESSING 
while (iter~=length(message))   %While not EOF
    line=message(iter);  
    while (abs(message(iter))~=10), iter=iter+1; line=[line message(iter)]; end; % GET THIS LINE
    iter=iter+1;

    fields = parse_fields(line);  %PARSE THIS LINE
    out(data_out)=str2num(char(fields(3)));  %STORE THE DATA
    data_out=data_out+1;
    if (data_out==21), break; end;   %EXIT ON COLLECTION OF ALL DATA
end;

