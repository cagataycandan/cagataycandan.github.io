function out=Jmat(N)
%function out=Jmat(N)
%
%Returns permutation matrix mapping x(n) sequence to x( (-n) mod N )
%
%Sept 2009
%CC

out=[1 zeros(1,N-1); ...
     zeros(N-1,1) fliplr(eye(N-1))];