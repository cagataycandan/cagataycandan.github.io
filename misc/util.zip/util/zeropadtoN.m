function out=zeropadtoN(vec,N),
%function out=zeropadtoN(vec,N)
%
% out = [vec 0 0 0 .. 0 ];
% where length of out is N
%
%August 2007,
%CC

if (size(vec,1)>1 & size(vec,2)>1),
    disp 'input should be column or row vector';
end;

out = [vec(:) ; zeros(N-length(vec),1)]; 

if size(vec,1)==1, %if input is row vector
    out=out.'; %then return a row vector
end;

