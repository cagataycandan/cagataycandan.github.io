function out=blockview(mat,blocksize,map)
%function out=blockview(mat,blocksize,map)
%View elements of a matrix blockwise
%
%2001, CC
%


Bx=blocksize(1);
By=blocksize(2);


if nargin==2,
   imshow(mat);
else
   imshow(mat,map);
   xlimbefore=get(gca,'xlim');
   ylimbefore=get(gca,'ylim');

   number_color=size(map,1);
%   map=[map ;  0.9961    0.8672    0.5781];
end;
imzoom on

corry=1;corrx=1;

button=1;
while (button),
   [Y,X,button]=ginput(1);  %button=[],  when enter is pushed
   if button==1 | button==2, 
      X=round(X); Y=round(Y);
      coorx=floor(X/Bx)*Bx+1;
      coory=floor(Y/By)*By+1;
   else
      button
      switch button
      case 55, coorx=coorx-Bx;coory=coory-By; %numeric keyboard ``7''
      case 56, coorx=coorx-Bx;				     %numeric keyboard ``8''
      case 57, coorx=coorx-Bx;coory=coory+By; %9 
      case 52, coory=coory-By;                %4
      case 54, coory=coory+By;                %6
      case 49, coorx=coorx+Bx;coory=coory-By; %1
      case 50, coorx=coorx+Bx;                %2
      case 51, coorx=coorx+Bx;coory=coory+By; %3
      otherwise
      end; %switch-case
      
      coorx=max(0,coorx);coory=max(0,coory); %check the range
      coorx=min(size(mat,2),coorx);coory=min(size(mat,1),coory);
   end; %if button==
   
   dum=mat;
   block=mat(coorx:(coorx+Bx-1),coory:(coory+By-1)),

if nargin==2, 
   dum(coorx:(coorx+Bx-1),coory:(coory+By-1))=zeros(Bx,By);imshow(dum);
else   
   dum(coorx:(coorx+Bx-1),coory:(coory+By-1))=zeros(Bx,By);
   imshow(dum,map);  
   end; %if nargin
   
   title([num2str(coorx) ':' num2str(coorx+Bx-1) ' , ' num2str(coory) ':' num2str(coory+By-1)]);
   set(gca,'xlim',xlimbefore);
   set(gca,'ylim',ylimbefore);
   xlabel('Zoom in-out or Press a key to continue');
   pause;
   xlimbefore=get(gca,'xlim');
   ylimbefore=get(gca,'ylim');

   
end;% while
   

