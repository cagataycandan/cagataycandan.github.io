function out=blockflipud(I,N)
%Blockwise flipud operation
% x=[ A B C D]'
% blcokflipud(x,2) => [C D A B]'
%
%Oct 8, 2001
%CC

M=size(I,1);

if (rem(M,N)~=0), disp ('N should be a divisor of number of rows of I'); return; end;

out=zeros(size(I));
for k=1:N, 
   dum=I(k:N:M,:);
   out(k:N:M,:)=flipud(dum);
end;


