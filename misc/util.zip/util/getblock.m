function out=getblock(I,num,blocksize),
% function out=getblock(I,num)
% returns the block number of ``num'' of the input image I
% blocks are 8 x 8 by default under otherwise is stated at blocksize 
% 
% oct 29, 2002.
% CC
%

if nargin == 3,  
    bRow=blocksize(1); bCol=blocksize(2); 
else             
    bRow=8;            bCol=8;
end;

[M,N]=size(I); 
blocks_in_a_col=ceil(M/bRow); 

block_row=rem(num,blocks_in_a_col); 
block_col=floor(num/blocks_in_a_col)+1;

if block_row==0, block_row=blocks_in_a_col; block_col=block_col-1;end;

out=I(((block_row-1)*bRow+1):(block_row*bRow),((block_col-1)*bCol+1):(block_col*bCol));

