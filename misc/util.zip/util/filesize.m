function count=filesize(filename)
fid = fopen(filename,'r');
[A,count]= fread(fid,inf);
fclose(fid);

