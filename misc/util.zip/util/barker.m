function out = barker(length)
%function out = barker(length)
%Outputs Barker Code of given length
%
%CC Sept.2011, 
%

switch length
    case 1, out = [-1];
    case 2, out = [-1 1];
    case 3, out =  [-1 -1 1]; 
    case 4, out =  [-1 -1 1 -1]; 
    case 5, out =  [-1 -1 -1 1 -1]; 
    case 7, out =  [-1 -1 -1 1 1 -1 1]; 
    case 11, out =  [-1 -1 -1 1 1 1 -1 1 1 -1 1]; 
    case 13, out =  [-1 -1 -1 -1 -1 1 1 -1 -1 1 -1 1 -1]; 
    otherwise
        disp (['No Barker code for the given length, possible lengths' ...
              '={1,2,3,4,5,7,11,13}']);
end;        