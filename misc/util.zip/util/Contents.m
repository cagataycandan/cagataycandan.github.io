%THE LIST OF UTILITY PROGRAMS AS OF SEPT. 2011
%
%
% almosteq.m     ---TESTS if input parameters are almost equal---
% barker.m       ---Returns Barker Sequence
% bis            ---Open a clear page and brings luck
% blockfliplr.m  ---blockwise flip operation---
% blockflipud.m  ---blockwise flip operation---
% blockview.m    ---blockwise data viewer---
% cconvm.m       ---circular convolution matrix---
% cshift.m       ---circular shift by N
% downbyn        ---- decimate by n 
% even.m         ---returns 1 if input is an even number---
% filesize.m     ---gives the size (in bytes) of a file---
% givemepix.m    --------good stuff------
% interpbyrect   --- upsamples by rectangle function
% interpbylinear --- linear interpolation by a factor
% Jmat           ---- x[n] -> x[(-n) mod N] 
% legendstr      ---- Legend utility
% mat2metuemail  ----generates metu emails from 7 digit student numbers
% mat2latex.m    ---converts matrix to latex format---
% parse_data_out.m 
% parse_fields.m ----parses data out of a string separatedby space
% plotfft        ---- plots fft of input vector 
% prpoly.m       ----print polynomial (mutation of a command)----
% psnr.m         ----shows the psnr in DB---
% rect.m         ----rectangle function
% seefig.m       ----figure navigator---
% sortrows.m     
% trmouse.m      ----tracks mouse position at the figure title---
% img_qi.m       ----Image quality index, see help for the paper describing the index---
% zeropadtoN     ---- out = [vec 0 0 0 .. 0 ];
% cshift         ---- circular shift by N units [a b c ] --> [c b a]
% legenstr.m     ---- formats a legend string from numerical vectors
% topten.m       ---- top ten largest size file in a directory by S. Koc
% trmouse        ---- Tracks mouse in the current figure
% zigzag         ---- Zig zag scan (JPEG)

%
% JPEG RELATED: 
% read_trans     ----mex file to read transform coefficients / quantization table from a jpg file
%                    usage: [coef,quant]=read_trans('lena90.jpg');
% write_trans    ----mex file to write modified transform coefficients to a jpg file
%                    usage: write_trans(new_coef,'in.jpg','out.jpg');
%
% cjpeg.exe      ----dos executable to compress an image by jpeg, 
%                    many options: important ones, -dct float, -grayscale 
%
% 
