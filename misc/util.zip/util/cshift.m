function out=cshift(x,N)
%function out=cshift(x,N)
%Circular Shift by N units
%
% x=[a b c],
% out = cshift(x,1);
% out = [c b a];
%
%Dec. 2010, Sept. 2011
%CC
%
columnvec=0;
if size(x,1)>1, x=x.'; columnvec=1; end;

N=rem(N,length(x));

if N>0,
    out = [x(end-(N-1):end) x(1:(end-N))];
else
    out = [x(-N+1:end) x(1:-N)];
end;

if columnvec==1, out=out(:); end;