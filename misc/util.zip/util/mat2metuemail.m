function msg=mat2metuemail(a)
%msg=mat2metuemail(a)
%
%CC

msg=[];
a1=floor(a/10);
for k=1:length(a1), 
    msg=[msg 'e' num2str(a1(k)) '@metu.edu.tr , '];
end;