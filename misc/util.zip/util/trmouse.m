function trmouse
%Tracks mouse in figure showing position of pointer at title

%Include this line in main
%set(gcf,'WindowButtonMotionFcn','trmouse;')
%Update WindowButtonUpFcn ;

ax=gca;
y=get(ax,'CurrentPoint');
xlim=get(ax,'Xlim');
ylim=get(ax,'Ylim');
if (xlim(1) <= y(1,1) & y(1,1) <= xlim(2) & ...
                ylim(1) <= y(1,2) & y(1,2) <= ylim(2))
title ([ num2str(y(1)) ':' num2str(y(3))]);
else 
	title ([ '? : ?']);
end;
