function seefigure(v)
%Lets you go through the the figures you requested

figures= get(0,'Children');
if nargin==0;v=sort(figures);end;
for k=1:length(v),if any(figures==v(k)), figure(v(k));pause;end;end;