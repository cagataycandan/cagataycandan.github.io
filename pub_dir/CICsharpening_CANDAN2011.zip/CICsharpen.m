function [coef,delays,hdes] = CICsharpen(downby,order,weight,passb,stopb)
%function [coef,delays,hdes] = CICsharpen(downby,order,weight,passb,stopb)
%
% Generates optimal sharpening coefficients for CIC decimation filters
% (See explanations)
% 
%
% INPUTS:
% -------
% downby : decimation ratio 
% order  : order of the sharpening polynomial (order = #coef + 1)
% weight : stopband / passband ripple weighting factor 
% passb  : passband definition, [0 1/4] -> DC to pi/4
% stopb  : stopband definition, [1/2 1] -> pi/2 to pi
%
% if passb or stopb is not provided 
%        passb=[0 1/downby]; stopb=[1/downby*1.5 1]
%
% OUTPUTS:
% --------
% coef   : coefficients of sharpening polynomial
% delays : delays required for the implementation (see explanations)
% hdes   : filter 
% 
% Note : You can run fvtool(hdes) at the workplace to examine the design. 
%
% Cagatay Candan
% METU, Ankara, TURKEY
% Oct. 2011, 
% 

if exist('passb')==0, passb=[0 1/downby]; end;
if exist('stopb')==0, stopb=[1/downby*1.5 1]; end;

NFFT=128;
hp=conv(ones(1,downby),ones(1,downby))/downby^2;
h=[hp(downby:end) zeros(1,NFFT-2*downby+1) hp(1:downby-1)];
hf=real(fft(h)); hf=hf(:);

if passb(2)>1/downby, disp('Caution: Passband exceeds 1/downby'); end;
passband=(floor(passb(1)*NFFT/2):floor(passb(2)*NFFT/2)) + 1;
stopband=(floor(stopb(1)*NFFT/2):floor(stopb(2)*NFFT/2)) + 1;

% CONSTRUCT PASSBAND CONSTRAINTS
thisone=hf(passband);
dum1=[ones(size(thisone)) repmat(thisone,[1 order])];
dum2=ones(size(thisone))*[0:order];
Amat=dum1.^dum2;
Amatp1=-[ones(size(thisone)) Amat];
bp1=-1*ones(size(thisone));

Amatp2=[-ones(size(thisone)) Amat];
bp2=ones(size(thisone));

Amatp=[Amatp1; Amatp2];
bp=[bp1; bp2];

%CONSTRUCT STOPBAND CONSTRAINTS
thisone=hf(stopband);
dum1=[ones(size(thisone)) repmat(thisone,[1 order])];
dum2=ones(size(thisone))*[0:order];
Amat=dum1.^dum2;
Amats1=-[ones(size(thisone)) Amat];
bs1=zeros(size(thisone));

Amats2=[-ones(size(thisone)) Amat];
bs2=zeros(size(thisone));

Amats=[Amats1; Amats2];
Amats(:,1)=Amats(:,1)/weight;
bs=[bs1; bs2];

%CONSTRUCT EQUALITY CONSTRAINT AT DC FREQ.
Aeq=[0 ones(1,order+1)];beq=1;

%CONSTRUCT EQUALITY CONSTRAINT FOR IMAGE NULLING
AeqImg=[0 1 zeros(1,order)];beqImg=0;  %OPTIONAL
Aeq=[Aeq; AeqImg]; beq=[beq; beqImg];  %OPTIONAL

%SOLVE FOR OPTIMAL COEF.
f=[1 zeros(1,order+1)];
dum=linprog(f,[Amatp; Amats],[bp;bs],Aeq,beq);
coef=dum(2:end);

%GENERATE THE FILTER
fillength=(order-1)*(length(hp)-1)+length(hp);
center=(fillength-1)/2+1; 
hdes=zeros(1,fillength);
hdes(center) = hdes(center) + coef(1);

hdum=1;
delays=zeros(order+1,1);delays(1)=center;
for dum=1:order,
    hdum = conv(hdum,hp);
    q=length(hdum); qhalf=(q-1)/2;
    index = center-qhalf:center+qhalf;
    hdes(index)=hdes(index) + coef(dum+1)*hdum;
    delays(dum+1)=center-qhalf-1;
end;

%fvtool(hdes)
if nargout==0,
figure,
plotfft(hdes,'db',12); grid on; hold on;
plot(passb,[0 0],'-r');
plot(stopb,[-10 -10],'-r');


disp('-Power-/-Coef-/-Delay-/')
disp([(0:order)' coef delays])

hdesf=fft(hdes,NFFT);
hfnew=polyval(flipud(coef),hf);dumind=linspace(0,2,NFFT);
figure,
plot(dumind,max(-100,20*log10(abs([hf hfnew hdesf(:)]))));
end;

%fvtool(hdes)
    



