downby=5;

NFFT=128*4;
hp=conv(ones(1,downby),ones(1,downby))/downby^2;
h=[hp(downby:end) zeros(1,NFFT-2*downby+1) hp(1:downby-1)];
hf=real(fft(h)); hf=hf(:);

hclas=polyval([-2 3 0 0],hf);
[a,b,hdes2]=CICsharpen(downby,4,7);hdes2f=fft(hdes2(:),NFFT);
[a,b,hdes3]=CICsharpen(downby,6,7);hdes3f=fft(hdes3(:),NFFT);
[a,b,hdes4]=CICsharpen(downby,8,7);hdes4f=fft(hdes4(:),NFFT);
close all;

plotfft(hdes2,'dB',12,'linewidth',2); grid on; hold all;
plotfft(hdes3,'dB',12,'linewidth',2);
plotfft(hdes4,'dB',12,'linewidth',2);

%prototype
hpf=polyval([1 0],hf);
plot(linspace(-1,1,NFFT),max(-70,fftshift(20*log10(abs(hpf)))),'--','linewidth',2);

%quantized 4th order
hq4f=polyval([10 -23 15 -1 0],hf);
plot(linspace(-1,1,NFFT),fftshift(20*log10(abs(hq4f))),'--','linewidth',2);


dum = axis;
axis([0 1 dum(3) 5])
xtickstr=[0:0.1:1];
set(gca,'xtick',xtickstr);set(gca,'XtickLabelMode','auto');

plot([0 1/downby],[0 0],'--k','linewidth',2);
plot([1/downby 1/downby],[dum(3) 0],'--k','linewidth',2);
plot([1/downby*1.5 1/downby*1.5],[dum(3) -10],'--k','linewidth',2);
plot([1/downby*1.5 1],[-10 -10],'--k','linewidth',2);
plot([1 1],[dum(3) -10],'--k','linewidth',2);

text(0.55,  -14, 'Stopband','fontsize',11,'fontweight','bold');
text(0.02,  -14, 'Passband','fontsize',11,'fontweight','bold');
legend('4th Order','6th Order','8th Order','Location','SouthWest');

h=xlabel('Frequency/\pi (rad/sample)');set(h,'fontsize',11);
h=ylabel('Magnitude (dB)');set(h,'fontsize',11);