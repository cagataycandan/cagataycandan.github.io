function out = myfun(w,Astop,Apass,weight)

out1 = abs(Astop*w);
out2 = abs(1 - abs(Apass*w)); 

out = [weight*out1; out2];


