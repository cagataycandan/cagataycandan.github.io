% min-max freq response for different weights same x0
clear all; close all; clc;

% file name and directory and figure scaling
srcDirFile = [mfilename '.pdf'];
dstDirFile = ['./../latex/figs/matlab/' mfilename '.pdf'];
tblDir = ['./../latex/tbls/'];
figScale = [100 100 750 700];        %[pos_x pos_y width_x width_y]

st_ratios  = [12 16 13 18]; %linear stagger
% st_ratios  = [8 9 7 10]; %linear stagger
% st_ratios  = [10 13 11 14 12]; %linear stagger
x0_rand = 0;

iterationNo = 20; % iteration fpr optimized minmax
stpAttn = 0;

weightMMX = [260 790 3510 5590]; % filter weights

% frequency percentage in terms of Fmax
fc_percent = 0.05;
ft_percent = 0.2;
fp_percent = 10;

numpoints_pass=200; 
numpoints_stop=200;
prf_comfac=100;  %in Hz

% MNMX Filter %%%%%%%%%%%%%%%%%%%%%%%%%%%
N = length(st_ratios);
if x0_rand == 1
    x0=rand(N+1,1);
else
    x0 = f_binomial_coefs(N+1);
end

% Maximum frequency
 Fmax = f_lcm(st_ratios,prf_comfac);
% Fmax = 400000;

fc = fc_percent*Fmax/min(st_ratios);
ft = ft_percent*Fmax/min(st_ratios);
fp = fp_percent*Fmax/min(st_ratios);

N = length(st_ratios);
%%%%%%%%%%%%%%
prf_vec = Fmax./st_ratios;
pri_vec = 1./prf_vec;

% if fd > Fmax-fc,  
%     disp('fdesired should be less than Fmax - Fcutoff'); 
%     Fmax, fc,
%     return;
% end;

sampling_vec = [0 filter(1,[1 -1],pri_vec)];

%%Response in stop-band
fstop = linspace(0,fc,numpoints_stop);
Astop = exp(j*2*pi*fstop(:)*sampling_vec);
Astop = [Astop; conj(Astop)];

%DONT-CARE BAND
% don't care band is in between stop and pass bands
%  dont care band --> wc < |w| < wc x 1.5

%%Response in passband
fpass = linspace(ft,fp,numpoints_pass); 
Apass = exp(j*2*pi*fpass(:)*sampling_vec);
Apass = [Apass; conj(Apass)];
faxis  = linspace(0,fp,512*16);

faxis_n =  faxis/max(prf_vec);
fc_n    =  fc/max(prf_vec);
ft_n    =  ft/max(prf_vec);
fp_n    =  fp/max(prf_vec);

Atotal = exp(j*2*pi*faxis(:)*sampling_vec);

% LS Filter %%%%%%%%%%%%%%%%%%%%%%%
W_MMX = zeros(N+1,length(weightMMX));
for num = 1:length(weightMMX)
W_MNMX(:,num) = f_minmaxf(st_ratios,prf_comfac,fc,ft,fp,weightMMX(num), ...
    numpoints_stop,numpoints_pass,x0);
end

mmxresp = Atotal*W_MNMX;
mmxresp_dB = 20*log10(abs(mmxresp));

paramsMMX = zeros(length(weightMMX),4);

for i=1:length(weightMMX)
paramsMMX(i,:) = f_PerfParams(mmxresp(:,i),fc,ft,fp,faxis);
end

%%% plot results **********************************************************
figMMX = figure('Name','MMX Filter Design');
stRatiosStr = num2str(st_ratios(1));

if (N>1)
for i=2:N
 tmpStr = num2str(st_ratios(i));   
stRatiosStr =[stRatiosStr ':' tmpStr ];
end
end

% subplot(2,1,1)
fig1=subplot(2,2,1:2)
plot(faxis_n, max(-100,20*log10(abs(mmxresp))),'-','LineWidth',1);  hold all;

dum = axis; 
plot([0 0],[dum(3) 0],'-r','linewidth',3);
plot([fc_n fc_n],[dum(3) 0],'-r','linewidth',3);
plot([ft_n ft_n],[dum(3) 0],'-b','linewidth',3);
plot([fp_n fp_n],[dum(3) 0],'-b','linewidth',3);
hold off;
grid on;

title(['Min-Max Design, SR=' stRatiosStr ', f_c=' num2str(fc_percent) ', f_t=' ...
    num2str(ft_percent) ', f_p=' num2str(fp_percent) ]); 
xlabel('f_{doppler} / f_{max}'); ylabel('|H_{mmx}(f)| (dB)')
legend('W =260','W =790','W =3510','W =5590', 'Location','SouthEast')

fig2=subplot(2,2,3); 
fc_ind = find(2*fc>faxis);

plot(faxis_n(fc_ind), max(-100,20*log10(abs(mmxresp(fc_ind,:)))),'-','LineWidth',1);  hold all;
dum = axis; 
plot([0 0],[dum(3) 0],'-r','linewidth',3);
plot([fc_n fc_n],[dum(3) 0],'-r','linewidth',3);
hold off;
grid on;

title('Zoomed Stopband Response'); 
xlabel('f_{doppler} / f_{max}'); ylabel('|H_{mmx}(f)| (dB)')

fig2=subplot(2,2,4); 
% fc_ind = find(2*fc>faxis);
fc_ind = 3000:4500;

plot(faxis_n(fc_ind), max(-100,20*log10(abs(mmxresp(fc_ind,:)))),'-','LineWidth',1);  hold all;
dum = axis; 
hold off;
grid on;

title('Zoomed Max. Deviation Response'); 
xlabel('f_{doppler} / f_{max}'); ylabel('|H_{mmx}(f)| (dB)')

% **************************************************************************
% debug
paramsMMX

% % write pdfs
set(figMMX, 'PaperPositionMode','auto');
set(figMMX, 'Position', figScale);

print(figMMX,'-dpdf',srcDirFile) ;

unix_cropPDF_cmd = ['pdfcrop.exe ' srcDirFile ' ' srcDirFile]
[s,r]=unix(unix_cropPDF_cmd);
if (s==0) display('pdf cropped succesfully'); end;

unix_mvPDF_cmd = ['mv ' srcDirFile ' ' dstDirFile];
[s,r]=unix(unix_mvPDF_cmd);
if (s==0) display('moved file succesfully'); end; %0 means success
