function Fmax=f_lcm(st_ratios,prf_comfac)
%%GCD, LCM Hesabi
lcmratios=st_ratios(1);
for thisone=st_ratios(2:end),
    lcmratios=lcm(lcmratios,thisone);
end;
Fmax = lcmratios*prf_comfac;