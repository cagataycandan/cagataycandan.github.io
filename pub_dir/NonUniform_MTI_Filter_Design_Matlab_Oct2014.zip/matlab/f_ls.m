function LS_vec=f_ls(st_ratios,prf_comfac,fc,ft,fd,W,numpoints_stop,numpoints_pass)

% Least square filter design for staggered mti 

L_mti = length(st_ratios)+1;
%L_mti = length(sampling_vec);

%fc_ratio = 0.02;
%alpha = 1000000; % weight factor for cutoff and passband

Fmax = f_lcm(st_ratios,prf_comfac); % Maximum frequency

%  Prfbs = lcmratios*prf_comfac;
N = length(st_ratios);
%%%%%%%%%%%%%%
prf_vec = Fmax ./st_ratios;
%  prf_vec = fd ./st_ratios;
pri_vec = 1./prf_vec;

%n pulse binomial mti coefficients
%n indicates the number of coefficients
%mti = f_binomial_coefs(L_mti);
%%%

% frequnecy points
fstop = linspace(0,fc,numpoints_stop);
fpass = linspace(fc,fd,numpoints_pass); 
fpoints = [fstop fpass];
w = 2*pi*fpoints;

wc = 2*pi*fc;
wt = 2*pi*ft;
wd = 2*pi*fd ;  %DIKKAT!


% fpoints = linspace(-Prfbs,Prfbs,10000);
% fpoints = linspace(-fd,fd,10000);
w = 2*pi*fpoints;
% sample vectors
sampling_vec = [0 filter(1,[1 -1],pri_vec)]+eps;

%sampling_vec = [0.0 0.279 0.483 0.633 0.808, 1.047].*10e-3;
e_vec = exp(j*(w).'*sampling_vec);

%fdummy = max(fpoints);
%fc = fc_ratio*fdummy;
%fd = fdummy;

% fstop = linspace(0,fc,numpoints_stop);
% Astop = exp(j*2*pi*fstop(:)*sampling_vec);
% 
% Apass = exp(j*2*pi*fpass(:)*sampling_vec);
% Apass = [Apass; conj(Apass)];

%sampling vectors (eps ise used in order to prevent NAN)
%sampling_vec_ls = [0 filter(1,[1 -1],pri_vec)]+eps;

sampling_vec_cur = sampling_vec;

%mat_r = (N+2-L_mti);
LS_mat = [];

%%%%%%%
%Hd = eval(int(sym('exp(-j*w1*sampling_vec_cur)'),'w1',wc,wd))';

Hd1 = eval(int(sym('exp(j*w1*sampling_vec_cur)'),'w1',-wd,-wc))';
Hd2 = eval(int(sym('exp(j*w1*sampling_vec_cur)'),'w1',wc,wd))';

% normalize
 Hd1 = Hd1 / (wd-wc);
 Hd2 = Hd2 / (wd-wc);

Hd = Hd1 + Hd2;

  Ar = zeros(L_mti,L_mti);
  Ar1 = zeros(L_mti,L_mti);
  Ar2a = zeros(L_mti,L_mti);
  Ar2b = zeros(L_mti,L_mti);

    for i=1:L_mti
        Ar1(i,:) = eval(int(sym('exp(-j*w1*(sampling_vec_cur-(sampling_vec_cur(i)+eps)))'),'w1',-wc,wc));
         Ar2a(i,:) = eval(int(sym('exp(-j*w1*(sampling_vec_cur-(sampling_vec_cur(i)+eps)))'),'w1',wc,wd));
        Ar2b(i,:) = eval(int(sym('exp(-j*w1*(sampling_vec_cur-(sampling_vec_cur(i)+eps)))'),'w1',-wd,-wc));
        
    end

    % normalize
     Ar1 = Ar1 / (2*wc);
     Ar2a = Ar2a / (wd-wc);
     Ar2b = Ar2b / (wd-wc);
%     
   Ar = W.*Ar1 + Ar2a +Ar2b ;
      
   weigths = inv(Ar)*Hd;
   
  lambda = (ones(1,L_mti)*inv(Ar)*Hd)/(ones(1,L_mti)*inv(Ar)*ones(L_mti,1));
  weigths = inv(Ar)*(Hd - lambda*ones(L_mti,1));
  b = (Hd - lambda*ones(L_mti,1));
  LS_vec = weigths;
  
%   weigths = inv([Ar.'*Ar ones(L_mti,1); ones(L_mti,1).' 0])*[Ar.'*Hd; 0];
%   LS_vec = weigths(1:end-1);
   
   LS_vec = LS_vec./norm(LS_vec);
      
% % there were length mat_r times weigth vectors
% %for ind = 1:mat_r
%     %sampling_vec_cur = sampling_vec_ls(ind:ind+L_mti-1);
%     % desired freq response
%     %Hd = eval(int(sym('exp(-j*w1*sampling_vec_cur)'),'w1',wc,wd))';
%     % integral coefficient matrix
%    % Ar = zeros(L_mti,L_mti);
%     %Ar1 = zeros(L_mti,L_mti);
%     %Ar2a = zeros(L_mti,L_mti);
%     %Ar2b = zeros(L_mti,L_mti);
% 
%     % calculate matrix coefficients
% %     for i=1:L_mti
% %         Ar(i,:) = eval(int(sym('exp(j*w1*(sampling_vec_cur-(sampling_vec_cur(i)+eps)))'),'w1',0,wd));
% %     end
%     
%     %%%
%     
%     %%%Use weight in coefficent matrix integral
%     for i=1:L_mti
%         Ar1(i,:) = eval(int(sym('exp(j*w1*(sampling_vec_cur-(sampling_vec_cur(i)+eps)))'),'w1',-wc,wc));
%     end
%     
%     for i=1:L_mti
%         Ar2a(i,:) = eval(int(sym('exp(j*w1*(sampling_vec_cur-(sampling_vec_cur(i)+eps)))'),'w1',wc,wd));
%         Ar2b(i,:) = eval(int(sym('exp(j*w1*(sampling_vec_cur-(sampling_vec_cur(i)+eps)))'),'w1',-wd,-wc));
%       end
%     
%    %%%
%    Ar = W.*Ar1 + Ar2a +Ar2b ;
%    %%%
%     
%    % calculate the filter coefficients
%     weigths = inv(Ar)*Hd;
%     lambda = (ones(1,L_mti)*inv(Ar)*Hd)/(ones(1,L_mti)*inv(Ar)*ones(L_mti,1));
%     weigths = inv(Ar)*(Hd - lambda*ones(L_mti,1));
%     b = (Hd - lambda*ones(L_mti,1))
%     
%     % form the MTI matrix
%     LS_mat(ind,:) = [zeros(1,ind-1) weigths.'  zeros(1,N+2-L_mti-ind)];
% %alp = Ar\Hd;
% %end

%LS2 = real(LS_mat); %%%DIKKAT! 
%LS2 = LS_mat; %%%DIKKAT! 
 

