function w_pr = f_prinsen_coefs(st_ratios,prf_comfac)

L_mti = length(st_ratios)+1;               %length of mti filter

%%GCD, LCM Hesabi
Fmax = f_lcm(st_ratios,prf_comfac);

% Maximum frequency
Fmax = f_lcm(st_ratios,prf_comfac);
N = length(st_ratios);
%%%%%%%%%%%%%%
prf_vec = Fmax./st_ratios;
pri_vec = 1./prf_vec;

% pri_vec = [1.111 1.000 1.091 1.058];

sampling_vec = [0 filter(1,[1 -1],pri_vec)];

% prinsen
w_0 = 1;         % set first coeficient to 1

% calculate Vandemonde matrix
T = zeros(L_mti-1,L_mti-1); 
for i=1:L_mti-1
T(i,:)=sampling_vec(2:end).^(i-1);
end    
u1 = [1 zeros(1,L_mti-2)];
% return calculated coefficients
w_pr =[w_0; -w_0*inv(T)*u1.'];