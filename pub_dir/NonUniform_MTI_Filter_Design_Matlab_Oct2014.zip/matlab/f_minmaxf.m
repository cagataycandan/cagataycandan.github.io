function w_mm = f_minmaxf(st_ratios,prf_comfac,fc,ft,fd,W,numpoints_stop,numpoints_pass,x0)

%%GCD, LCM Hesabi
lcmratios=st_ratios(1);
for thisone=st_ratios(2:end),
    lcmratios=lcm(lcmratios,thisone);
end;

Fmax = lcmratios*prf_comfac;

N = length(st_ratios);
%%%%%%%%%%%%%%
prf_vec = Fmax./st_ratios;
pri_vec = 1./prf_vec;

sampling_vec = [0 filter(1,[1 -1],pri_vec)];

%%Response in stop-band
fstop = linspace(0,fc,numpoints_stop);
Astop = exp(j*2*pi*fstop(:)*sampling_vec);
Astop = [Astop; conj(Astop)];

%DONT-CARE BAND
% don't care band is in between stop and pass bands
%  dont care band --> wc < |w| < wc x 1.5

%%Response in passband
fpass = linspace(ft,fd,numpoints_pass); 
Apass = exp(j*2*pi*fpass(:)*sampling_vec);
Apass = [Apass; conj(Apass)];

options = optimset('MaxFunEvals',10e3,'TolCon',1e-8,'Display','off');
Aeq=ones(1,N+1); beq=0; 
%x0=rand(N+1,1); 
[w_mm,fval] = fminimax(@(w) f_myfun(w,Astop,Apass,W),x0,[],[],Aeq,beq,[],[],[],options);