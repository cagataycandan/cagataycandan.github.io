% Uniform vs. Stagger Response
% 30.09.2012
clear all; close all; clc;
%%%%
% Stagger ratio and input train

st_ratios3  = [4 4]; %linear stagger
st_ratios4  = [3 5]; %linear stagger

figScale = [100 100 620 250]; % wwin

% file name and directory
srcDirFile = [mfilename '.pdf'];
dstDirFile = ['./../latex/figs/matlab/' mfilename '.pdf'];

% common prf factor
prf_comfac=10;  %in Hz

% frequency percentage in terms of Fmax
fc_percent = 0.01;
fd_percent = 1;

% Maximum and Normalized frequencies
Fmax3 = f_lcm(st_ratios3,prf_comfac);
fc = fc_percent*Fmax3;
fd = fd_percent*Fmax3;

% number of point adjustments in stop/pass bands
N = length(st_ratios3);
numpoints_pass=200; 
numpoints_stop=20;
prf_comfac=10;  %in Hz

% sampling time conversions
prf_vec3 = Fmax3./st_ratios3;
pri_vec3 = 1./prf_vec3;

prf_vec4 = Fmax3./st_ratios4;
pri_vec4 = 1./prf_vec4;

sampling_vec3 = [0 filter(1,[1 -1],pri_vec3)];
sampling_vec4 = [0 filter(1,[1 -1],pri_vec4)];


faxis3  = linspace(0,2*Fmax3,512);

% normalize freq axis for Doppler/ max(PRF)
A3 = exp(j*2*pi*faxis3(:)*sampling_vec3);
A4 = exp(j*2*pi*faxis3(:)*sampling_vec4);

% uniform and stagger responses
uniResp =  A3*[1 -2 1]';
uniResp = uniResp/sqrt((uniResp.*uniResp));
uniResp_dB = 20*log10(abs(uniResp));

stagResp = A4*[1 -2 1]';
stagResp = stagResp/sqrt((stagResp.*stagResp));
stagResp_dB = 20*log10(abs(stagResp));

% plot results
faxis3_n =  faxis3/10;
fig1 = figure();
plot(faxis3_n, uniResp_dB(:,480),'-b','LineWidth',1); hold on;
plot(faxis3_n, stagResp_dB(:,129),'-r','LineWidth',1); grid;
title('Normalized Magnitude Response for  Uniform and Staggered PRI'); 
xlabel('Normalized Frequency (f / f_{bs})'); ylabel('Magnitude (dB)')
legend('Uniform','Non-Uniform','Location','SouthEast')
axis([0 8 -60 0])
% % write pdfs
set(fig1, 'PaperPositionMode','auto');
set(fig1, 'Position', figScale);

print(fig1,'-dpdf',srcDirFile) ;

unix_cropPDF_cmd = ['pdfcrop.exe ' srcDirFile ' ' srcDirFile]
[s,r]=unix(unix_cropPDF_cmd);
if (s==0) display('pdf cropped succesfully'); end;

unix_mvPDF_cmd = ['mv ' srcDirFile ' ' dstDirFile];
[s,r]=unix(unix_mvPDF_cmd);
if (s==0) display('moved file succesfully'); end; %0 means success


