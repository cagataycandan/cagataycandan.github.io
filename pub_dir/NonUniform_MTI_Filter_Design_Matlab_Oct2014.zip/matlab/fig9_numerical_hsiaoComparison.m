% numerical comparison of hsiao
clear all; close all; clc;

% file name and directory
figDir = './../latex/figs/matlab/pgf/';
tblDir = './../latex/table_tex/';
writerName = 'Hsiao';
isWrite =1;

% file name and directory and figure scaling
figScale = [100 100 750 700];        %[pos_x pos_y width_x width_y]
tblDir = ['./../latex/tbls/'];

srcDirFile1 = [mfilename '_FR' '.pdf'];
dstDirFile1 = ['./../latex/figs/matlab/' mfilename '_FR' '.pdf'];

srcDirFile2 = [mfilename '_IF' '.pdf'];
dstDirFile2 = ['./../latex/figs/matlab/' mfilename '_IF' '.pdf'];

tblName1 = [mfilename '_FR' '.tex']; 
tblName2 = [mfilename '_IF' '.tex']; 
tblName3 = [mfilename '_Weights' '.tex']; 

st_ratios = [11 11 10 12 14 11];

wLs     = [ 0.1003   -0.3418    0.6104   -0.6036    0.3382  -0.1424    0.0390].';

wCvx    = [-0.06157  0.27169 -0.56918   0.62933 -0.40092   0.19392  -0.06326].';

wMinmax = [0.0793   -0.2969    0.5753   -0.6174    0.3872   -0.1967    0.0693].';

wHsiao  = [0.080892 -0.301091 0.584633 -0.617309 0.379645 -0.179466 0.059962]';


fc_percent = 0.2;
sg_percent = 0.05;
ft_percent = 0.3;
fp_percent = 4.5;
fm_percent = 10;

% clutterModel = 'Gauss';
clutterModel = 'Uniform';
useConstantWeights = 1;
% clutterModel = 'ScanRadar';
stopAttnBound = -35;

isPrint = 0;
iterationNo = 10;
numpointsPass=200; 
numpointsStop=200;
prf_comfac=100;  %in Hz

SNR_dB = 10; 
CNR_dB = 50;
rpm = 40; %rev. per minute
azim_BW_deg = 1.7;

% Maximum frequency
Fmax = f_lcm(st_ratios,prf_comfac);
N = length(st_ratios);
%%%%%%%%%%%%%%
prf_vec = Fmax./st_ratios;
pri_vec = 1./prf_vec;

fc = fc_percent*Fmax/min(st_ratios);
ft = ft_percent*Fmax/min(st_ratios);
fp = fp_percent*Fmax/min(st_ratios);
fm = fm_percent*Fmax/min(st_ratios);

sg = sg_percent*Fmax/min(st_ratios);


if fp > Fmax-fc,  
    disp('fdesired should be less than Fmax - Fcutoff'); 
    Fmax, fc,
    return;
end;

sampling_vec = [0 filter(1,[1 -1],pri_vec)];

%%Response in stop-band
fstop = linspace(0,fc,numpointsStop);
Astop = exp(j*2*pi*fstop(:)*sampling_vec);
Astop = [Astop; conj(Astop)];

%DONT-CARE BAND
% don't care band is in between stop and pass bands
%  dont care band --> wc < |w| < wt

%%Response in passband
fpass = linspace(ft,fp,numpointsPass); 
Apass = exp(j*2*pi*fpass(:)*sampling_vec);
Apass = [Apass; conj(Apass)];
faxis  = linspace(0,fp,512*16);

% normalize freq axis for Doppler/ max(PRF)
faxis_n =  faxis/max(prf_vec);
fc_n     =  fc/max(prf_vec);
ft_n     =  ft/max(prf_vec);
fp_n    =  fp/max(prf_vec);

Atotal = exp(j*2*pi*faxis(:)*sampling_vec);

% plot firstly frequency response value for calculated filter coefficients
% prinsen filter

wLs = wLs./norm(wLs);
lsresp_dB      = f_dB20(abs(Atotal*wLs));

wCvx = wCvx./norm(wCvx);
cvxresp_dB      = f_dB20(abs(Atotal*wCvx));

wMinmax = wMinmax./norm(wMinmax);
mmresp_dB     = f_dB20(abs(Atotal*wMinmax));

wHsiao = wHsiao./norm(wHsiao);
hsiaoresp_dB   = f_dB20(abs(Atotal*wHsiao));


lsresp      = (abs(Atotal*wLs));
cvxresp      = (abs(Atotal*wCvx));
mmresp      = (abs(Atotal*wMinmax));
hsiaoresp   = (abs(Atotal*wHsiao));

% Plot freq response of the filters ******************************
fig1 = figure();
stRatiosStr = num2str(st_ratios(1));

if (N>1)
for i=2:N
 tmpStr = num2str(st_ratios(i));   
stRatiosStr =[stRatiosStr ':' tmpStr ];
end
end

figsub = subplot(2,2,1:2)
plot(faxis_n, max(-70,lsresp_dB),'LineWidth',1);  hold all;  
plot(faxis_n, max(-70,cvxresp_dB),'LineWidth',1);  hold all;  
plot(faxis_n, max(-70,mmresp_dB),'LineWidth',1);
plot(faxis_n, max(-70,hsiaoresp_dB),'LineWidth',1);
axis([0 4.5 -70 10])

dum = axis; 
plot([0 0],[dum(3) 0],'-r','linewidth',3);
plot([fc_n fc_n],[dum(3) 0],'-r','linewidth',3);
plot([ft_n ft_n],[dum(3) 0],'-b','linewidth',3);
plot([fp_n fp_n],[dum(3) 0],'-b','linewidth',3);
hold off;
grid on;

title(['Comparison of Filters with Stagger Period:' stRatiosStr]); 
xlabel('Normalized Frequency (f_d / f_{max})'); ylabel('Amplitude (dB)')
legend('Ls','Cvx','Minmax','Hsiao','Location','SouthEast');
%********************************************************************

magnifyOnFigure(...
        figsub,...
        'units', 'pixels',...
        'magnifierShape', 'ellipse',...
        'initialPositionSecondaryAxes', [200 260 140 80],...
        'initialPositionMagnifier',     [445 330 20 30],...    
        'mode', 'interactive',...    
        'displayLinkStyle', 'straight',...        
        'edgeWidth', 0.5,...
        'edgeColor', 'black',...
        'secondaryAxesFaceColor', [0.9 0.91 0.91]... 
            ); 


sb2 = subplot(2,2,3)
fc_ind = find(2*fc>faxis);
%ind = 1:floor(length(faxis_n)/50);
plot(faxis_n(fc_ind), max(-75,lsresp_dB(fc_ind)),'LineWidth',1); hold all;
plot(faxis_n(fc_ind), max(-75,cvxresp_dB(fc_ind)),'LineWidth',1);
plot(faxis_n(fc_ind), max(-75,mmresp_dB(fc_ind)),'LineWidth',1);
plot(faxis_n(fc_ind), max(-75,hsiaoresp_dB(fc_ind)),'LineWidth',1);  

dum = axis; 
plot([0 0],[dum(3) 0],'-r','linewidth',3);
plot([fc_n fc_n],[dum(3) 0],'-r','linewidth',3);
axis([0 0.25 -75 -10])
hold off;
grid on;

title('Zoomed Stopband Response'); 
xlabel('Normalized Frequency (f_d / f_{max})'); ylabel('Amplitude (dB)')

sb3 = subplot(2,2,4)
fc_ind = 1000:2300;
%ind = 1:floor(length(faxis_n)/50);
plot(faxis_n(fc_ind), max(-70,lsresp_dB(fc_ind)),'LineWidth',1); hold all;
plot(faxis_n(fc_ind), max(-70,cvxresp_dB(fc_ind)),'LineWidth',1);
plot(faxis_n(fc_ind), max(-70,mmresp_dB(fc_ind)),'LineWidth',1);
plot(faxis_n(fc_ind), max(-70,hsiaoresp_dB(fc_ind)),'LineWidth',1);  

dum = axis; 
hold off;
grid on;

title('Zoomed Max. Deviation Response'); 
xlabel('Normalized Frequency (f_d / f_{max})'); ylabel('Amplitude (dB)')

% parameters for comparison
PerfParams(1,:) = f_PerfParams(lsresp,fc,ft,fp,faxis);
PerfParams(2,:) = f_PerfParams(cvxresp,fc,ft,fp,faxis);
PerfParams(3,:) = f_PerfParams(mmresp,fc,ft,fp,faxis);
PerfParams(4,:) = f_PerfParams(hsiaoresp,fc,ft,fp,faxis);

%print performance params
sName = char('Ls','Cvx','Minmax','Hsiao','Prinsen','Binom');
fprintf('\tStp Attn\tMean Error\tMax Deviation  \n')
for i=1:4
fprintf('%s \t: %0.4g\t %0.4g\t %0.4g\t %0.4g\t %0.4g\t \n',sName(i,:),PerfParams(i,:))
end
fprintf('\n')

% % write pdfs
set(fig1, 'PaperPositionMode','auto');
set(fig1, 'Position', figScale);

print(fig1,'-dpdf',srcDirFile1) ;

unix_cropPDF_cmd = ['pdfcrop.exe ' srcDirFile1 ' ' srcDirFile1]
[s,r]=unix(unix_cropPDF_cmd);
if (s==0) display('pdf cropped succesfully'); end;

unix_mvPDF_cmd = ['cp ' srcDirFile1 ' ' dstDirFile1];
[s,r]=unix(unix_mvPDF_cmd);
if (s==0) display('moved file succesfully'); end; %0 means success

