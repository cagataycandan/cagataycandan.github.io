function PARAMS=f_PerfParams(resp,fc,ft,fp,faxis)

resp_dB = 20*log10(abs(resp));

PARAMS = zeros(1,4); % since 3 parameters so far

%%Calculated passband error
%find passband samples
passband_ind_start = max(find(ft > faxis));
passband_ind_end= max(find(fp >= faxis));


resp_dB_pass = abs(resp_dB(passband_ind_start:passband_ind_end));

% error = sum(resp_dB_pass)./length(resp_dB_pass);
% error = mean(resp_dB_pass);
error = 20*log10(mean(abs(resp(passband_ind_start:passband_ind_end))));


max_dev = max(resp_dB_pass);
fc_ind = max(find(fc>faxis));    
stop_attn = resp_dB(fc_ind);

% stop ripple
mStop = mean(resp(1:fc_ind));
stopRipple = 20*log10(abs(mStop));

PARAMS = [stopRipple, stop_attn, error, max_dev] ;

end    

%find absolute value of the deviation for the passband
%minmaxresp_dB = abs(20*log10(abs(minmaxresp(passband_ind:end,:))));
%Calculate the passband error
%error = sum(minmaxresp_dB)./length(minmaxresp_dB);

%Maximum deviation from desired response
%max_dev = max(minmaxresp_dB);
%fc_ind = max(find(fc>faxis));
%Stopband attenuation 
% stop_attn_dB = 20*log10(abs(minmaxresp(fc_ind,:)))
% 
% y = [error, max_dev, stop_attn_dB];

% all return variables in terms of dB