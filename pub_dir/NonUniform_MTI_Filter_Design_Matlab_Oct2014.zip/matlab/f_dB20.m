function out_dB = dB20( input )
%Converts input to 20*log10(input)
%
out_dB = 20*log10(input);
end

