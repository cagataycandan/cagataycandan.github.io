% % numerical comparison of jacomini
clear all; close all; clc;

% file name and directory
figDir = './../latex/figs/matlab/pgf/';
tblDir = './../latex/table_tex/';
writerName = 'Jacomini';
isWrite = 1;

% file name and directory and figure scaling
figScale = [100 100 750 700];        %[pos_x pos_y width_x width_y]
tblDir = ['./../latex/tbls/'];

srcDirFile1 = [mfilename '_FR' '.pdf'];
dstDirFile1 = ['./../latex/figs/matlab/' mfilename '_FR' '.pdf'];

srcDirFile2 = [mfilename '_IF' '.pdf'];
dstDirFile2 = ['./../latex/figs/matlab/' mfilename '_IF' '.pdf'];

tblName1 = [mfilename '_FR' '.tex']; 
tblName2 = [mfilename '_IF' '.tex']; 
tblName3 = [mfilename '_Weights' '.tex']; 

st_ratios = [279 204 150 175 239]; %jacomini 1

figScale1 = [100 100 600 460];        %[pos_x pos_y width_x width_y]
figScale2 = [100 100 600 460];        %[pos_x pos_y width_x width_y]

wLs       =  [ 0.0760   -0.3731    0.7290   -0.5562    0.1188    0.0054].';

wCvx      =  [ 0.0093   -0.1388    0.5435   -0.7270    0.3887  -0.0756].';

wMinmax   =  [0.0018   -0.1200    0.5317   -0.7355    0.3956 -0.0737].';

wJacomini =  [0.059 -0.332 0.695 -0.534 0.092 0.023].';

fc_percent = 0.09;
sg_percent = 0.09;
ft_percent = 0.18;
fp_percent = 2.8;
fm_percent = 3;

% clutterModel = 'Gauss';
clutterModel = 'Uniform';
useConstantWeights = 1;
% clutterModel = 'ScanRadar';
stopAttnBound = -35;

isPrint = 0;
%minmax optimization iteration value
iterationNo = 10;
numpointsPass=400; 
numpointsStop=200;
prf_comfac=10;  %in Hz

SNR_dB = 10; 
CNR_dB = 50;
rpm = 40; %rev. per minute
azim_BW_deg = 1.7;

% Maximum frequency
Fmax = f_lcm(st_ratios,prf_comfac);
N = length(st_ratios);
%%%%%%%%%%%%%%
prf_vec = Fmax./st_ratios;
pri_vec = 1./prf_vec;

fc = fc_percent*Fmax/min(st_ratios);
ft = ft_percent*Fmax/min(st_ratios);
fp = fp_percent*Fmax/min(st_ratios);
fm = fm_percent*Fmax/min(st_ratios);

sg = sg_percent*Fmax/min(st_ratios);


if fp > Fmax-fc,  
    disp('fdesired should be less than Fmax - Fcutoff'); 
    Fmax, fc,
    return;
end;

sampling_vec = [0 filter(1,[1 -1],pri_vec)];

%%Response in stop-band
fstop = linspace(0,fc,numpointsStop);
Astop = exp(j*2*pi*fstop(:)*sampling_vec);
Astop = [Astop; conj(Astop)];

%DONT-CARE BAND
% don't care band is in between stop and pass bands
%  dont care band --> wc < |w| < wt

%%Response in passband
fpass = linspace(ft,fp,numpointsPass); 
Apass = exp(j*2*pi*fpass(:)*sampling_vec);
Apass = [Apass; conj(Apass)];
faxis  = linspace(0,fm,512*16);

% normalize freq axis for Doppler/ max(PRF)
faxis_n  =  faxis/max(prf_vec);
fc_n     =  fc/max(prf_vec);
ft_n     =  ft/max(prf_vec);
fp_n     =  fp/max(prf_vec);
fm_n     =  fm/max(prf_vec);


Atotal = exp(j*2*pi*faxis(:)*sampling_vec);

% plot firstly frequency response value for calculated filter coefficients
% prinsen filter


wLs = wLs./norm(wLs);
lsresp_dB      = f_dB20(abs(Atotal*wLs));

wCvx = wCvx./norm(wCvx);
cvxresp_dB      = f_dB20(abs(Atotal*wCvx));

wMinmax = wMinmax./norm(wMinmax);
mmresp_dB     = f_dB20(abs(Atotal*wMinmax));

wJacomini = wJacomini./norm(wJacomini);
Jacominiresp_dB   = f_dB20(abs(Atotal*wJacomini));

lsresp      = (abs(Atotal*wLs));
cvxresp      = (abs(Atotal*wCvx));
mmresp      = (abs(Atotal*wMinmax));
Jacominiresp   = (abs(Atotal*wJacomini));


% Plot freq response of the filters ******************************
fig1 = figure();
stRatiosStr = num2str(st_ratios(1));

if (N>1)
for i=2:N
 tmpStr = num2str(st_ratios(i));   
stRatiosStr =[stRatiosStr ':' tmpStr ];
end
end

figsub = subplot(2,2,1:2)
plot(faxis_n, max(-60,lsresp_dB),'LineWidth',1);  hold all;  
plot(faxis_n, max(-60,cvxresp_dB),'LineWidth',1);
plot(faxis_n, max(-60,mmresp_dB),'LineWidth',1);
plot(faxis_n, max(-60,Jacominiresp_dB),'LineWidth',1);

dum = axis; 
plot([0 0],[dum(3) 0],'-r','linewidth',3);
plot([fc_n fc_n],[dum(3) 0],'-r','linewidth',3);
plot([fc_n fc_n]*1.5,[dum(3) 0],'-b','linewidth',3);
plot([fp_n fp_n],[dum(3) 0],'-b','linewidth',3);
hold off;
grid on;

title(['Comparison of Filters with Stagger Period:' stRatiosStr]); 
xlabel('Normalized Frequency (f_d / f_{max})'); ylabel('Amplitude (dB)')
legend('Ls','Cvx','Minmax','Jacomini','Location','SouthEast')
%********************************************************************

magnifyOnFigure(...
        figsub,...
        'units', 'pixels',...
        'magnifierShape', 'ellipse',...
        'initialPositionSecondaryAxes', [200 260 110 70],...
        'initialPositionMagnifier',     [355 345 15 15],...    
        'mode', 'interactive',...    
        'displayLinkStyle', 'straight',...        
        'edgeWidth', 0.5,...
        'edgeColor', 'black',...
        'secondaryAxesFaceColor', [0.9 0.91 0.91]... 
            ); 


sb2 = subplot(2,2,3)
fc_ind = find(2*fc>faxis);
%ind = 1:floor(length(faxis_n)/50);
plot(faxis_n(fc_ind), max(-90,lsresp_dB(fc_ind)),'LineWidth',1); hold all;
plot(faxis_n(fc_ind), max(-90,cvxresp_dB(fc_ind)),'LineWidth',1);
plot(faxis_n(fc_ind), max(-90,mmresp_dB(fc_ind)),'LineWidth',1);
plot(faxis_n(fc_ind), max(-90,Jacominiresp_dB(fc_ind)),'LineWidth',1);
axis([0 0.15 -85 -10])

dum = axis; 
plot([0 0],[dum(3) 0],'-r','linewidth',3);
plot([fc_n fc_n],[dum(3) 0],'-r','linewidth',3);
hold off;
grid on;

title('Zoomed Stopband Response'); 
xlabel('Normalized Frequency (f_d / f_{max})'); ylabel('Amplitude (dB)')

%%%% 
subplot(2,2,4)
% fc_ind = find(2*fc>faxis);
fc_ind = 4000:6000;
%ind = 1:floor(length(faxis_n)/50);
plot(faxis_n(fc_ind), max(-80,lsresp_dB(fc_ind)),'LineWidth',1); hold all;
plot(faxis_n(fc_ind), max(-80,cvxresp_dB(fc_ind)),'LineWidth',1);
plot(faxis_n(fc_ind), max(-80,mmresp_dB(fc_ind)),'LineWidth',1);
plot(faxis_n(fc_ind), max(-80,Jacominiresp_dB(fc_ind)),'LineWidth',1);  

hold off;
grid on;

title('Zoomed Max. Deviation Response'); 
xlabel('f_{doppler} / f_{max}'); ylabel('|H_{ls}(f)| (dB)')

% parameters for comparison
PerfParams(1,:) = f_PerfParams(lsresp,fc,ft,fp,faxis);
PerfParams(2,:) = f_PerfParams(cvxresp,fc,ft,fp,faxis);
PerfParams(3,:) = f_PerfParams(mmresp,fc,ft,fp,faxis);
PerfParams(4,:) = f_PerfParams(Jacominiresp,fc,ft,fp,faxis);

% % write pdfs
set(fig1, 'PaperPositionMode','auto');
set(fig1, 'Position', figScale);

print(fig1,'-dpdf',srcDirFile1) ;

unix_cropPDF_cmd = ['pdfcrop.exe ' srcDirFile1 ' ' srcDirFile1]
[s,r]=unix(unix_cropPDF_cmd);
if (s==0) display('pdf cropped succesfully'); end;

unix_mvPDF_cmd = ['mv ' srcDirFile1 ' ' dstDirFile1];
[s,r]=unix(unix_mvPDF_cmd);
if (s==0) display('moved file succesfully'); end; %0 means success

sName = char('Ls','Cvx','Minmax','Jacomini','Prinsen','Binom');

fprintf('\tStp Attn\tMean Error\tMax Deviation  \n')
for i=1:4
fprintf('%s \t:  %0.4g\t %0.4g\t %0.4g\t %0.4g\t \n',sName(i,:),PerfParams(i,:));
end
fprintf('\n')

