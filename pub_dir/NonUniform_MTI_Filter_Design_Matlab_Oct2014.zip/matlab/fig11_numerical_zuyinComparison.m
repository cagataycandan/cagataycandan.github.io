% % numerical comparison of zuyin
clear all; close all; clc;

% file name and directory
figDir = './../../ltx/figs/matlab/';
tblDir = './../../ltx/table_tex/';
writerName = 'Zuyin'; 
isWrite = 1;

% file name and directory and figure scaling
figScale = [100 100 750 700];        %[pos_x pos_y width_x width_y]
tblDir = ['./../latex/tbls/'];

srcDirFile1 = [mfilename '_FR' '.pdf'];
dstDirFile1 = ['./../latex/figs/matlab/' mfilename '_FR' '.pdf'];

srcDirFile2 = [mfilename '_IF' '.pdf'];
dstDirFile2 = ['./../latex/figs/matlab/' mfilename '_IF' '.pdf'];

tblName1 = [mfilename '_FR' '.tex']; 
tblName2 = [mfilename '_IF' '.tex']; 
tblName3 = [mfilename '_Weights' '.tex']; 


st_ratios = [838 1135 892 1108 1027]; %zuyin 1

wZuyin = [1 -3.741 7.781 -7.679 3.320 -0.681].';

wLs       = [ 0.1305   -0.4080    0.6774   -0.5640    0.1961 -0.0320].';

wCvx      = [-0.0728    0.2819   -0.6228    0.6533   -0.3093  0.0698].';

wMinmax   = [ 0.0833   -0.2957    0.6182   -0.6454    0.3175  -0.0780].';

wZuyin = [1 -3.741 7.781 -7.679 3.320 -0.681].';

fc_percent = 0.072;
sg_percent = 0.036;
ft_percent = 0.1;
fp_percent = 5;
fm_percent = 7;

clutterModel = 'Gauss';
useConstantWeights = 1;
% clutterModel = 'ScanRadar';
stopAttnBound = -35;

isPrint = 0;
%minmax optimization iteration value
iterationNo = 10;
numpointsPass=200; 
numpointsStop=200;
prf_comfac=100;  %in Hz

SNR_dB = 10; 
CNR_dB = 50;
rpm = 40; %rev. per minute
azim_BW_deg = 1.7;

% Maximum frequency
Fmax = f_lcm(st_ratios,prf_comfac);
N = length(st_ratios);
%%%%%%%%%%%%%%
prf_vec = Fmax./st_ratios;
pri_vec = 1./prf_vec;

fc = fc_percent*Fmax/min(st_ratios);
ft = ft_percent*Fmax/min(st_ratios);
fp = fp_percent*Fmax/min(st_ratios);
fm = fm_percent*Fmax/min(st_ratios);

sg = sg_percent*Fmax/min(st_ratios);

if fp > Fmax-fc,  
    disp('fdesired should be less than Fmax - Fcutoff'); 
    Fmax, fc,
    return;
end;

sampling_vec = [0 filter(1,[1 -1],pri_vec)];

%%Response in stop-band
fstop = linspace(0,fc,numpointsStop);
Astop = exp(j*2*pi*fstop(:)*sampling_vec);
Astop = [Astop; conj(Astop)];

%DONT-CARE BAND
% don't care band is in between stop and pass bands
%  dont care band --> wc < |w| < wt

%%Response in passband
fpass = linspace(ft,fp,numpointsPass); 
Apass = exp(j*2*pi*fpass(:)*sampling_vec);
Apass = [Apass; conj(Apass)];
faxis  = linspace(0,fm,512*16);

% normalize freq axis for Doppler/ max(PRF)
faxis_n =  faxis/max(prf_vec);
fc_n    =  fc/max(prf_vec);
ft_n    =  ft/max(prf_vec);
fp_n    =  fp/max(prf_vec);
fm_n    =  fm/max(prf_vec);

Atotal = exp(j*2*pi*faxis(:)*sampling_vec);

% plot firstly frequency response value for calculated filter coefficients
% prinsen filter


wLs = wLs./norm(wLs);
lsresp_dB      = f_dB20(abs(Atotal*wLs));

wCvx = wCvx./norm(wCvx);
cvxresp_dB     = f_dB20(abs(Atotal*wCvx));

wMinmax = wMinmax./norm(wMinmax);
mmresp_dB     = f_dB20(abs(Atotal*wMinmax));

wZuyin = wZuyin./norm(wZuyin);
Zuyinresp_dB   = f_dB20(abs(Atotal*wZuyin));

lsresp      = (abs(Atotal*wLs));
cvxresp      = (abs(Atotal*wCvx));
mmresp      = (abs(Atotal*wMinmax));
Zuyinresp   = (abs(Atotal*wZuyin));

% Plot freq response of the filters ******************************
fig1 = figure();
stRatiosStr = num2str(st_ratios(1));

if (N>1)
for i=2:N
 tmpStr = num2str(st_ratios(i));   
stRatiosStr =[stRatiosStr ':' tmpStr ];
end
end

figsub = subplot(2,2,1:2)
plot(faxis_n, max(-60,lsresp_dB),'LineWidth',1);  hold all;  
plot(faxis_n, max(-60,cvxresp_dB),'LineWidth',1);
plot(faxis_n, max(-60,mmresp_dB),'LineWidth',1);
plot(faxis_n, max(-60,Zuyinresp_dB),'LineWidth',1);

dum = axis; 
plot([0 0],[dum(3) 0],'-r','linewidth',3);
plot([fc_n fc_n],[dum(3) 0],'-r','linewidth',3);
plot([fc_n fc_n]*1.5,[dum(3) 0],'-b','linewidth',3);
plot([fp_n fp_n],[dum(3) 0],'-b','linewidth',3);
hold off;
grid on;

title(['Magnitude Response, Zuyin''s Stagger Period ' stRatiosStr]); 
xlabel('Normalized Frequency (f_d / f_{max})'); ylabel('Magnitude (dB)')
legend('Ls','Cvx','MinMax','Zuyin','Location','SouthEast')
%********************************************************************

magnifyOnFigure(...
        figsub,...
        'units', 'pixels',...
        'magnifierShape', 'ellipse',...
        'initialPositionSecondaryAxes', [200 260 90 60],...
        'initialPositionMagnifier',     [358 323 20 50],...    
        'mode', 'interactive',...    
        'displayLinkStyle', 'straight',...        
        'edgeWidth', 0.5,...
        'edgeColor', 'black',...
        'secondaryAxesFaceColor', [0.9 0.91 0.91]... 
            ); 


subplot(2,2,3)
fc_ind = find(2*fc>faxis);
%ind = 1:floor(length(faxis_n)/50);
plot(faxis_n(fc_ind), max(-60,lsresp_dB(fc_ind)),'LineWidth',1); hold all;
plot(faxis_n(fc_ind), max(-60,cvxresp_dB(fc_ind)),'LineWidth',1);
plot(faxis_n(fc_ind), max(-60,mmresp_dB(fc_ind)),'LineWidth',1);
plot(faxis_n(fc_ind), max(-60,Zuyinresp_dB(fc_ind)),'LineWidth',1);  

dum = axis; 
plot([0 0],[dum(3) 0],'-r','linewidth',3);
plot([fc_n fc_n],[dum(3) 0],'-r','linewidth',3);
axis([0 0.14 -60 -10]);
hold off;
grid on;

title('Zoomed Stopband Response'); 
xlabel('Normalized Frequency (f_d / f_{max})'); ylabel('Magnitude (dB)')

subplot(2,2,4)
%fc_ind = find(2*fc>faxis);
fc_ind = 2000:2400;
%ind = 1:floor(length(faxis_n)/50);
plot(faxis_n(fc_ind), max(-60,lsresp_dB(fc_ind)),'LineWidth',1); hold all;
plot(faxis_n(fc_ind), max(-60,cvxresp_dB(fc_ind)),'LineWidth',1);
plot(faxis_n(fc_ind), max(-60,mmresp_dB(fc_ind)),'LineWidth',1);
plot(faxis_n(fc_ind), max(-60,Zuyinresp_dB(fc_ind)),'LineWidth',1);  
hold off;
grid on;

title('Zoomed Max. Deviation Response'); 
xlabel('f_{doppler} / f_{max}'); ylabel('|H_{ls}(f)| (dB)')
% parameters for comparison
PerfParams(1,:) = f_PerfParams(lsresp,fc,ft,fp,faxis);
PerfParams(2,:) = f_PerfParams(cvxresp,fc,ft,fp,faxis);
PerfParams(3,:) = f_PerfParams(mmresp,fc,ft,fp,faxis);
PerfParams(4,:) = f_PerfParams(Zuyinresp,fc,ft,fp,faxis);
% % 

% % write pdfs
set(fig1, 'PaperPositionMode','auto');
set(fig1, 'Position', figScale);

print(fig1,'-dpdf',srcDirFile1) ;

unix_cropPDF_cmd = ['pdfcrop.exe ' srcDirFile1 ' ' srcDirFile1]
[s,r]=unix(unix_cropPDF_cmd);
if (s==0) display('pdf cropped succesfully'); end;

unix_mvPDF_cmd = ['mv ' srcDirFile1 ' ' dstDirFile1];
[s,r]=unix(unix_mvPDF_cmd);
if (s==0) display('moved file succesfully'); end; %0 means success

%print performance params
sName = char('Ls','Cvx','MinMax','Zuyin','Prinsen','Binom');
fprintf('\tStp Attn\tMean Error\tMax Deviation  \n')
for i=1:4
fprintf('%s \t: %0.4g\t %0.4g\t %0.4g\t %0.4g\t \n',sName(i,:),PerfParams(i,:))
end
fprintf('\n')

