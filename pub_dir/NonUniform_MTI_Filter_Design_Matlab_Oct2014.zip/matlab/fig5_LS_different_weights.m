% Least square freq response for different weights
% 03.04.2014
clear all; close all; clc;

% file name and directory and figure scaling
srcDirFile = [mfilename '.pdf'];
dstDirFile = ['./../latex/figs/matlab/' mfilename '.pdf'];
tblDir = ['./../latex/tbls/'];
figScale = [100 100 750 700]; %[pos_x pos_y width_x width_y]

% Stagger interval and weights
st_ratios  = [25 30 27 31]; 
weightLS = [1e3 1e4 1e5 1e6 ]; 

% frequency percentage in terms of Fmax
fc_percent = 0.04;
ft_percent = 0.1;
fp_percent = 10;
fm_percent = 12;
prf_comfac=100;  %in Hz
Fmax = f_lcm(st_ratios,prf_comfac);

% number of point adjustments in stop/pass bands
N = length(st_ratios);
numpoints_pass=200; 
numpoints_stop=200;


% sampling time conversions
prf_vec = Fmax./st_ratios;
pri_vec = 1./prf_vec;

fc = fc_percent*max(prf_vec);
ft = ft_percent*max(prf_vec);
fp = fp_percent*max(prf_vec);
fm = fm_percent*max(prf_vec);

%%%%%%%%%%%%%%
if fp > Fmax-fc,  
    disp('fdesired should be less than Fmax - Fcutoff'); 
    Fmax, fc,
    return;
end;

sampling_vec = [0 filter(1,[1 -1],pri_vec)];

%%Response in stop-band
fstop = linspace(0,fc,numpoints_stop);
Astop = exp(j*2*pi*fstop(:)*sampling_vec);
Astop = [Astop; conj(Astop)];

%DONT-CARE BAND
% don't care band is in between stop and pass bands
%  dont care band --> wc < |w| < wc x 1.5

%%Response in passband
fpass = linspace(ft,fp,numpoints_pass); 
Apass = exp(j*2*pi*fpass(:)*sampling_vec);
Apass = [Apass; conj(Apass)];
faxis  = linspace(0,fm,512*16);

% normalize freq axis for Doppler/ max(PRF)
faxis_n =  faxis/max(prf_vec);
fc_n    =  fc/max(prf_vec);
ft_n    =  ft/max(prf_vec);
fp_n    =  fp/max(prf_vec);

Atotal = exp(j*2*pi*faxis(:)*sampling_vec);

% LS Filter %%%%%%%%%%%%%%%%%%%%%%%
W_LS = zeros(N+1,length(weightLS));
for num = 1:length(weightLS)
    W_LS(:,num) = f_ls(st_ratios,prf_comfac,fc,ft,fp,weightLS(num),numpoints_stop,numpoints_pass); 
end

% response for plot
lsresp = Atotal*W_LS;
lsresp_dB = 0*log10(abs(lsresp));

% performance measures
paramsLS = zeros(length(weightLS),4);

for i=1:length(weightLS)
paramsLS(i,:) = f_PerfParams(lsresp(:,i),fc,ft,fp,faxis);
end

%%% plot results **********************************************************
figLS = figure('Name','LS Filter Design');
stRatiosStr = num2str(st_ratios(1));

if (N>1)
for i=2:N
 tmpStr = num2str(st_ratios(i));   
stRatiosStr =[stRatiosStr ':' tmpStr ];
end
end

fig1=subplot(2,2,1:2)
plot(faxis_n, max(-80,20*log10(abs(lsresp))),'-','LineWidth',1);  hold all;

dum = axis; 
plot([0 0],[dum(3) 0],'-r','linewidth',2);
plot([fc_n fc_n],[dum(3) 0],'-r','linewidth',2);
plot([ft_n ft_n],[dum(3) 0],'-b','linewidth',2);
plot([fp_n fp_n],[dum(3) 0],'-b','linewidth',2);
hold off;
grid on;

title(['LS Design, SR=' stRatiosStr ', f_c=' num2str(fc_percent) ', f_t=' ...
    num2str(ft_percent) ', f_p=' num2str(fp_percent) ]); 
xlabel('f_{doppler} / f_{max}'); ylabel('|H_{ls}(f)| (dB)')
% legend(['W_f =' num2str(weightLS(1))],['W_f =' num2str(weightLS(2))], ...
%     ['W_f =' num2str(weightLS(3))],'Location','SouthEast')
legend('W =10^3','W =10^4','W =10^5','W =10^6', 'Location','SouthEast')

fig2=subplot(2,2,3)  
fc_ind = find(2*fc>faxis);

plot(faxis_n(fc_ind), max(-80,20*log10(abs(lsresp(fc_ind,:)))),'-','LineWidth',1);  hold all;
dum = axis; 
plot([0 0],[dum(3) 0],'-r','linewidth',2);
plot([fc_n fc_n],[dum(3) 0],'-r','linewidth',2);
plot([ft_n ft_n],[dum(3) 0],'-b','linewidth',2);
hold off;
grid on;

title('Zoomed Stopband Response'); 
xlabel('f_{doppler} / f_{max}'); ylabel('|H_{ls}(f)| (dB)')

fig3=subplot(2,2,4)  
fc_ind = find(10*fc>faxis);
fc_ind = 4500:5300;

%ind = 1:floor(length(faxis_n)/50);
plot(faxis_n(fc_ind), max(-80,20*log10(abs(lsresp(fc_ind,:)))),'-','LineWidth',1);  hold all;
hold off;
grid on;

title('Zoomed Max. Deviation Response'); 
xlabel('f_{doppler} / f_{max}'); ylabel('|H_{ls}(f)| (dB)')

% debug
paramsLS

% % write pdfs
set(figLS, 'PaperPositionMode','auto');
set(figLS, 'Position', figScale);

print(figLS,'-dpdf',srcDirFile) ;

unix_cropPDF_cmd = ['pdfcrop.exe ' srcDirFile ' ' srcDirFile]
[s,r]=unix(unix_cropPDF_cmd);
if (s==0) display('pdf cropped succesfully'); end;

unix_mvPDF_cmd = ['mv ' srcDirFile ' ' dstDirFile];
[s,r]=unix(unix_mvPDF_cmd);
if (s==0) display('moved file succesfully'); end; %0 means success

