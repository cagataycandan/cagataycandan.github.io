function [x,delta2]=f_cvx(st_ratios,prf_comfac,fc,ft,fd,weight,numpoints_stop,numpoints_pass);

N = length(st_ratios)+1;

%%GCD, LCM Hesabi
Fmax = f_lcm(st_ratios,prf_comfac);

pri_vec = st_ratios/Fmax;
sampling_vec = [0 filter(1,[1 -1],pri_vec)];

%%Response in stop-band
fstop = linspace(0,fc,numpoints_stop);
Astop = exp(j*2*pi*fstop(:)*sampling_vec);
Astop = [Astop; conj(Astop)];

%DONT-CARE BAND
% don't care band is in between stop and pass bands
%  dont care band --> wc < |w| < wc x 1.5

%%Response in passband
fpass = linspace(ft,fd,numpoints_pass); 
Apass = exp(j*2*pi*fpass(:)*sampling_vec);
Apass = [Apass; conj(Apass)];

cvx_quiet(true)
%CONSTRUCT CVX PROBLEM
cvx_begin
%     variable x(N) complex
    variable x(N) 
    variable delta1 
    minimize(delta1)
      subject to
    ones(1,N)*x == 0;
    abs(Astop*x) <= delta1;
    abs(Apass*x - 1) <= (weight)*delta1;
%    delta1 <= 0.0001;
  
cvx_end

% cvx_begin
%     variable x(N) complex
%     minimize(max(abs(Apass*x - 1)));
%     subject to
%      ones(1,N)*x == 0;
%      abs(Astop*x) <= 0.000000000000000001;
% cvx_end

% check if problem was successfully solved
disp(['Problem is ' cvx_status])
delta2 = delta1;
if ~strfind(cvx_status,'Solved')
  h = [];
end

x = x./norm(x);

%fprintf('Delta is : %.6f \n', delta1);