N=10; alpha = 1/5;
omega = 2*pi*1/8;
n=0:N-1;    
s=cos(omega*n);

Npoint=2; out2 = digscale(s,1-alpha,Npoint);
Npoint=4; out3 = digscale(s,1-alpha,Npoint);

nout = -1 + (1:length(out2)); sout = cos(omega*(1-alpha)*nout); 

h = figure(2); set(h,'Defaultaxesfontsize',12); set(h,'Defaulttextfontsize',12);

stem(0:length(s)-1,s,'s','markersize',10,'linewidth',2), hold all;
stem(0:length(sout)-1,sout,'r','markersize',11,'linewidth',2),
plot(0:length(out2)-1,out2,'bd','markersize',8,'linewidth',2),
plot(0:length(out3)-1,out3,'kp','markersize',8,'linewidth',2),

title(['Scaling x[n] = cos(\pi/4 n) by \beta = 4/5']); 
legend('Input','Desired Output','Scheme Output (N=2)', 'Scheme Output (N=4)','location','SouthEast');
xlabel('n');
hold off; 

%print -depsc -f1 ../Latex/figs/figcospiover4.eps