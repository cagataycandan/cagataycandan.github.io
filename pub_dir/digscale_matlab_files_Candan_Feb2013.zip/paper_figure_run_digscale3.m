N=500;
select=20:119;

freqvec=linspace(0.01,0.45,45);
Npointvec=2:6;
alpha = 0.1; 

beta = 1 - alpha;
n=0:N-1;

h = figure(1); set(h,'Defaultaxesfontsize',12); set(h,'Defaulttextfontsize',12);
set(gca,'xtick',0.05:0.05:0.45)

rmssignal = 1/sqrt(2);
semilogy(freqvec,rmssignal*ones(1,length(freqvec)),'--','linewidth',2); drawnow; hold all;

for Npoint = Npointvec,
    error = [];freqind = 0;
    for freq = freqvec,
        omega = 2*pi*freq;
        s=cos(omega*n);

        out = digscale(s,beta,Npoint);
        nout = -1 + (1:length(out));
        s2 = cos(omega*(1-alpha)*nout);
        e = s2-out;
        e = e(select);
        freqind = freqind + 1;
        error(freqind) = sqrt(mean(e.^2));

    end;
    semilogy(freqvec,error,'.-','linewidth',2,'markersize',20);  drawnow;
end;

title(['RMS error in the scaling of cos(\omegan) by \beta = ' num2str(beta) char (10) ...
       '(change of sampling rate by 1/\beta)']);

xlabel('normalized frequency (\omega / 2\pi)'); 
ylabel('RMS'); ;
dumstring={'Signal RMS', 'N = 2'  ,  'N = 3'  ...
         , 'N = 4'  ,  'N = 5' ,   'N = 6'};
legend(dumstring,'Location','SouthEast');
set(gca,'xtick',0.05:0.05:0.45)
dum = axis; axis([0 0.45 dum(3:4)]);
grid on
hold off;


%print -depsc -f1 ../Latex/figs/figrmserror2.eps